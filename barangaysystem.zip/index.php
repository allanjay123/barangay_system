<?php
require_once "config/init.php";

if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } elseif ($_SESSION['role'] === 'staff') {
        header("Location: admin/manage_incidents.php");
    } else {
        header("Location: user/dashboard.php");
    }
} else {
    header("Location: auth/login.php");
}
exit;
