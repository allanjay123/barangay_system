<?php
require_once "../config/init.php";

// Puwede mag-login nang paulit-ulit: kapag naka-login na at nag-GET lang, redirect; kapag nag-POST (submit), laging i-process ang login
if (isset($_SESSION['user_id']) && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.php");
    exit;
}

$error = "";
$role = isset($_POST['role']) ? $_POST['role'] : "resident";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = isset($_POST['role']) ? $_POST['role'] : "resident";
    $login_input = trim($_POST['fullname'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($login_input) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        $esc = $conn->real_escape_string($login_input);
        $esc_lower = $conn->real_escape_string(mb_strtolower($login_input));

        if ($role === 'resident') {
            $has_email_col = false;
            $cols = @$conn->query("SHOW COLUMNS FROM users");
            if ($cols) {
                while ($c = $cols->fetch_assoc()) {
                    if (strtolower($c['Field']) === 'email') {
                        $has_email_col = true;
                        break;
                    }
                }
            }
            if ($has_email_col) {
                $res = $conn->query("SELECT * FROM users WHERE (role = 'resident' OR role = 'user') AND (full_name = '$esc' OR (email IS NOT NULL AND email != '' AND LOWER(TRIM(email)) = '$esc_lower')) LIMIT 1");
            } else {
                $res = $conn->query("SELECT * FROM users WHERE (role = 'resident' OR role = 'user') AND full_name = '$esc' LIMIT 1");
            }
        } else {
            $res = $conn->query("SELECT * FROM users WHERE full_name = '$esc' AND role = '$role' LIMIT 1");
        }

        if ($res && $res->num_rows === 1) {
            $user = $res->fetch_assoc();
            $valid = false;
            if (!empty($user['password']) && strlen($user['password']) >= 60) {
                $valid = password_verify($password, $user['password']);
            }
            if (!$valid) {
                $valid = ($password === $user['password']);
            }

            if ($valid) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['fullname'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];

                if ($user['role'] === 'admin') {
                    header("Location: ../admin/dashboard.php");
                } elseif ($user['role'] === 'staff') {
                    header("Location: ../admin/manage_incidents.php");
                } else {
                    header("Location: ../user/dashboard.php");
                }
                exit;
            }
        }

        $error = $role === 'resident'
            ? "Account not found or wrong password. Use Full Name or Email you used when you registered."
            : "Admin not found or incorrect password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Barangay Incident System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .auth-page { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #0f766e 0%, #0d5d56 100%); }
        .auth-card { background: #fff; padding: 40px; border-radius: 16px; width: 100%; max-width: 420px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); }
        .auth-card h2 { margin: 0 0 8px; color: #0f172a; font-size: 1.5rem; text-align: center; }
        .auth-card .subtitle { color: #64748b; margin-bottom: 24px; font-size: 0.95rem; text-align: center; }
        .tab-buttons { display: flex; margin-bottom: 24px; background: #f1f5f9; border-radius: 10px; padding: 4px; }
        .tab-buttons button { flex: 1; padding: 12px; border: none; cursor: pointer; font-weight: 600; transition: 0.2s; background: transparent; color: #64748b; border-radius: 8px; }
        .tab-buttons button.active { background: #fff; color: var(--primary); box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .auth-card input { margin-bottom: 16px; }
        .auth-card button[type="submit"] { width: 100%; padding: 14px; font-size: 1rem; margin-top: 8px; }
        .auth-footer { text-align: center; margin-top: 24px; color: #64748b; }
        .auth-footer a { color: var(--primary); font-weight: 600; text-decoration: none; }
        .auth-footer a:hover { text-decoration: underline; }
        .success-msg { background: #d1fae5; color: #065f46; padding: 12px; border-radius: 8px; margin-bottom: 16px; text-align: center; }
        .login-hint { font-size: 0.85rem; color: #64748b; margin-top: -8px; margin-bottom: 12px; }
    </style>
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <h2>Barangay Incident System</h2>
        <p class="subtitle">Sign in to report and manage incidents</p>
        <?php if (isset($_GET['registered'])): ?><div class="success-msg">Registration successful! You can login anytime—full name or email.</div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <div class="tab-buttons">
            <button type="button" id="userTab" class="<?= $role === 'resident' ? 'active' : '' ?>" onclick="toggleRole('resident')">Resident</button>
            <button type="button" id="adminTab" class="<?= $role === 'admin' ? 'active' : '' ?>" onclick="toggleRole('admin')">Admin</button>
        </div>
        <form method="POST" id="loginForm">
            <input type="hidden" name="role" id="roleInput" value="<?= htmlspecialchars($role) ?>">
            <input type="text" name="fullname" placeholder="Full name or Email" value="<?= htmlspecialchars(isset($_POST['fullname']) ? $_POST['fullname'] : '') ?>" required autocomplete="username">
            <p class="login-hint">Resident: puwede kang mag-login ulit kahit ilang beses. Gamitin ang Full Name o Email na ginamit sa pag-register.</p>
            <input type="password" name="password" placeholder="Password" required autocomplete="current-password">
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
        <p class="auth-footer">Walang account? <a href="register.php">Mag-register</a></p>
    </div>
</div>
<script>
function toggleRole(r) {
    document.getElementById('roleInput').value = r;
    document.getElementById('userTab').classList.toggle('active', r === 'resident');
    document.getElementById('adminTab').classList.toggle('active', r === 'admin');
}
</script>
</body>
</html>