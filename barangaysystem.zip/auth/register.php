<?php
require_once "../config/init.php";

if (isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (strlen($full_name) < 2) {
        $error = "Full name must be at least 2 characters.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) && $email !== '') {
        $error = "Please enter a valid email address.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $full_name = $conn->real_escape_string($full_name);
        $email = $email ? $conn->real_escape_string($email) : null;
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        $check = $conn->query("SELECT id FROM users WHERE full_name='$full_name' " . ($email ? "OR email='$email'" : ""));
        if ($check && $check->num_rows > 0) {
            $error = "Username or email already exists!";
        } else {
            $emailVal = $email ? "'$email'" : "NULL";
            $sql = "INSERT INTO users (full_name, email, password, role, is_anonymous, created_at) VALUES ('$full_name', $emailVal, '$hashed', 'resident', 0, NOW())";
            if ($conn->query($sql)) {
                header("Location: login.php?registered=1");
                exit;
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .auth-page { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #0f766e 0%, #0d5d56 100%); }
        .auth-card { background: #fff; padding: 40px; border-radius: 16px; width: 100%; max-width: 420px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); }
        .auth-card h2 { margin: 0 0 8px; color: #0f172a; font-size: 1.5rem; }
        .auth-card .subtitle { color: #64748b; margin-bottom: 28px; font-size: 0.95rem; }
        .auth-card input { margin-bottom: 16px; }
        .auth-card button[type="submit"] { width: 100%; padding: 14px; font-size: 1rem; margin-top: 8px; }
        .auth-footer { text-align: center; margin-top: 24px; color: #64748b; }
        .auth-footer a { color: var(--primary); font-weight: 600; text-decoration: none; }
        .auth-footer a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <h2>Create Account</h2>
        <p class="subtitle">Register as a resident to report incidents</p>
        <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <form method="POST">
            <input type="text" name="full_name" placeholder="Full Name" value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required>
            <input type="email" name="email" placeholder="Email (optional)" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            <input type="password" name="password" placeholder="Password (min 6 characters)" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit" name="register" class="btn btn-primary">Register</button>
        </form>
        <p class="auth-footer">Already have an account? <a href="login.php">Login</a></p>
    </div>
</div>
</body>
</html>
