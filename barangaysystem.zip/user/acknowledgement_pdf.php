<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}
$id = (int)($_GET['id'] ?? 0);
$inc = $conn->query("SELECT i.*, u.full_name as reporter FROM incidents i LEFT JOIN users u ON i.user_id=u.id WHERE i.id=$id");
if (!$inc || $inc->num_rows === 0) {
    header("Location: my_reports.php");
    exit;
}
$i = $inc->fetch_assoc();
$is_admin = in_array($_SESSION['role'] ?? '', ['admin', 'staff']);
if (!$is_admin && (int)$i['user_id'] !== (int)$_SESSION['user_id']) {
    header("Location: my_reports.php");
    exit;
}
header("Location: acknowledgement_slip.php?id=$id&print=1");
exit;
