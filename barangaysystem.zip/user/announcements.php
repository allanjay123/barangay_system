<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['resident', 'user'])) {
    header("Location: ../auth/login.php");
    exit;
}
$data = $conn->query("SELECT * FROM announcements WHERE (expiry_date IS NULL OR expiry_date >= CURDATE()) ORDER BY is_pinned DESC, created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Resident Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="report_incident.php">Report Incident</a>
    <a href="my_reports.php">My Reports</a>
    <a href="announcements.php" class="active">Announcements</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Announcements</h2></div>
    <div style="max-width: 800px;">
        <?php if ($data && $data->num_rows > 0): while ($row = $data->fetch_assoc()): ?>
        <div class="card" style="display: block; margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <h3 style="margin: 0 0 8px; color: #0f172a;"><?= htmlspecialchars($row['title']) ?></h3>
                <?php if (!empty($row['urgency'])): ?><span class="badge badge-<?= $row['urgency'] === 'high' ? 'rejected' : 'pending' ?>"><?= htmlspecialchars($row['urgency']) ?></span><?php endif; ?>
            </div>
            <p style="margin: 12px 0; color: #475569; line-height: 1.6;"><?= nl2br(htmlspecialchars($row['content'])) ?></p>
            <small style="color: #94a3b8;"><?= date('M d, Y', strtotime($row['created_at'])) ?><?= !empty($row['expiry_date']) ? ' • Expires: ' . date('M d, Y', strtotime($row['expiry_date'])) : '' ?></small>
        </div>
        <?php endwhile; else: ?>
        <div class="card"><p style="margin: 0; color: #64748b;">No announcements at this time.</p></div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
