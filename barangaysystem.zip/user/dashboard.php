<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['resident', 'user'])) {
    header("Location: ../auth/login.php");
    exit;
}
$user_id = (int)$_SESSION['user_id'];
$total = $conn->query("SELECT COUNT(*) as total FROM incidents WHERE user_id=$user_id")->fetch_assoc()['total'] ?? 0;
$resolved = $conn->query("SELECT COUNT(*) as total FROM incidents WHERE user_id=$user_id AND status='Resolved'")->fetch_assoc()['total'] ?? 0;
$pending = $conn->query("SELECT COUNT(*) as total FROM incidents WHERE user_id=$user_id AND status='Pending'")->fetch_assoc()['total'] ?? 0;
$announcements = $conn->query("SELECT * FROM announcements WHERE (expiry_date IS NULL OR expiry_date >= CURDATE()) ORDER BY is_pinned DESC, created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="manifest" href="../manifest.json">
    <meta name="theme-color" content="#0f766e">
</head>
<body>
<div class="sidebar">
    <h3>Resident Panel</h3>
    <a href="dashboard.php" class="active">Dashboard</a>
    <a href="report_incident.php">Report Incident</a>
    <a href="my_reports.php">My Reports</a>
    <a href="announcements.php">Announcements</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
        <h2>Welcome, <?= htmlspecialchars($_SESSION['fullname']) ?></h2>
        <div id="notifBell" style="position:relative;">
            <span id="notifCount" class="notif-badge" style="display:none;">0</span>
            <button type="button" id="notifBtn" class="btn btn-secondary" style="padding:8px 14px;" title="Notifications">🔔 Notifications</button>
            <div id="notifDropdown" class="notif-dropdown" style="display:none;"></div>
        </div>
    </div>
    <p class="realtime-hint" style="color:#64748b; font-size:0.9rem; margin-top: -8px;">Stats update every 30 seconds.</p>
    <div id="statsRow">
        <div class="card"><h3>Total Reports</h3><h1 id="statTotal"><?= $total ?></h1></div>
        <div class="card"><h3>Resolved</h3><h1 id="statResolved"><?= $resolved ?></h1></div>
        <div class="card"><h3>Pending</h3><h1 id="statPending"><?= $pending ?></h1></div>
    </div>

    <div class="card" style="display:block; width:100%; max-width: 600px; margin-top: 20px;">
        <h3 style="margin: 0 0 8px; color: #0f172a; font-size: 1.1rem;">Feedback & Rating</h3>
        <p style="margin: 0 0 12px; color: #64748b; font-size: 0.95rem;">Rate and comment on your resolved reports. Your feedback helps improve our service.</p>
        <a href="my_reports.php" class="btn btn-primary">View My Reports & Give Feedback</a>
    </div>

    <?php if ($announcements && $announcements->num_rows > 0): ?>
    <div style="margin-top: 24px; background: #fff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); padding: 24px; max-width: 700px;">
        <h3 style="margin: 0 0 16px; color: #0f172a;">Latest Announcements</h3>
        <?php while ($a = $announcements->fetch_assoc()): ?>
        <div style="padding: 12px 0; border-bottom: 1px solid #e2e8f0;">
            <strong><?= htmlspecialchars($a['title']) ?></strong><?= !empty($a['urgency']) ? ' <span class="badge badge-' . ($a['urgency'] === 'high' ? 'rejected' : 'pending') . '">' . htmlspecialchars($a['urgency']) . '</span>' : '' ?>
            <p style="margin: 6px 0 0; color: #64748b; font-size: 0.95rem;"><?= nl2br(htmlspecialchars($a['content'])) ?></p>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>

    <div class="card" style="display:block; margin-top: 24px; max-width: 600px;">
        <h3 style="margin: 0 0 8px; color: #0f172a; font-size: 1.1rem;">📲 Download / Install Web App</h3>
        <p style="margin: 0 0 12px; color: #64748b; font-size: 0.95rem;">Add this app to your home screen for quick access.</p>
        <button type="button" id="installAppBtn" class="btn btn-primary">Install App (Add to Home Screen)</button>
        <div id="installInstructions" style="display:none; margin-top: 12px; padding: 12px; background: #f1f5f9; border-radius: 8px; font-size: 0.9rem; color: #475569;">
            <strong>How to install:</strong><br>
            • <strong>Android (Chrome):</strong> Menu (⋮) → “Add to Home screen” or “Install app”.<br>
            • <strong>iPhone (Safari):</strong> Share button → “Add to Home Screen”.
        </div>
    </div>
</div>
<style>
.notif-badge { position: absolute; top: -6px; right: -6px; background: #dc2626; color: #fff; font-size: 0.75rem; min-width: 20px; height: 20px; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; }
.notif-dropdown { position: absolute; top: 100%; right: 0; margin-top: 6px; background: #fff; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); min-width: 320px; max-height: 400px; overflow-y: auto; z-index: 1000; }
.notif-item { padding: 14px 18px; border-bottom: 1px solid #f1f5f9; cursor: pointer; }
.notif-item:hover { background: #f8fafc; }
.notif-item small { color: #94a3b8; }
</style>
<script>
(function() {
    var base = '../';
    function fetchStats() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', base + 'api/dashboard_stats.php');
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var d = JSON.parse(xhr.responseText);
                    if (d.ok) {
                        document.getElementById('statTotal').textContent = d.total || 0;
                        document.getElementById('statResolved').textContent = d.resolved || 0;
                        document.getElementById('statPending').textContent = d.pending || 0;
                    }
                } catch (e) {}
            }
        };
        xhr.send();
    }
    function fetchNotifs() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', base + 'api/notifications.php');
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var d = JSON.parse(xhr.responseText);
                    if (d.ok && d.notifications) {
                        var el = document.getElementById('notifCount');
                        var dd = document.getElementById('notifDropdown');
                        el.textContent = d.notifications.length;
                        el.style.display = d.notifications.length ? 'inline-flex' : 'none';
                        dd.innerHTML = d.notifications.length ? d.notifications.map(function(n) {
                            return '<div class="notif-item" data-id="' + n.id + '"><strong>' + (n.title || '') + '</strong><br><small>' + (n.message || '') + ' • ' + (n.created_at || '') + '</small></div>';
                        }).join('') : '<div class="notif-item">No new notifications</div>';
                    }
                } catch (e) {}
            }
        };
        xhr.send();
    }
    setInterval(fetchStats, 30000);
    setInterval(fetchNotifs, 15000);
    fetchNotifs();
    document.getElementById('notifBtn').onclick = function() {
        var dd = document.getElementById('notifDropdown');
        dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
    };
    document.getElementById('notifDropdown').addEventListener('click', function(e) {
        var item = e.target.closest('.notif-item[data-id]');
        if (item) {
            var id = item.getAttribute('data-id');
            var xhr = new XMLHttpRequest();
            xhr.open('POST', base + 'api/notifications.php?read=' + id);
            xhr.send();
            fetchNotifs();
        }
    });
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register(base + 'sw.js').catch(function() {});
    }
    var installBtn = document.getElementById('installAppBtn');
    var installInstructions = document.getElementById('installInstructions');
    var deferredPrompt;
    window.addEventListener('beforeinstallprompt', function(e) { e.preventDefault(); deferredPrompt = e; });
    installBtn.onclick = function() {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then(function() { deferredPrompt = null; });
        } else {
            installInstructions.style.display = 'block';
        }
    };
    if (window.matchMedia('(display-mode: standalone)').matches) {
        installBtn.textContent = 'App installed';
        installBtn.disabled = true;
    }
})();
</script>
</body>
</html>
