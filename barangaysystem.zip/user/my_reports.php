<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['resident', 'user'])) {
    header("Location: ../auth/login.php");
    exit;
}
$user_id = (int)$_SESSION['user_id'];
$data = $conn->query("SELECT * FROM incidents WHERE user_id=$user_id ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Reports - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Resident Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="report_incident.php">Report Incident</a>
    <a href="my_reports.php" class="active">My Reports</a>
    <a href="announcements.php">Announcements</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>My Reports</h2></div>
    <p style="color:#64748b; margin-top: -8px;">View status and give <strong>feedback & rating</strong> on resolved reports.</p>
    <?php if (isset($_GET['feedback'])): ?><div class="alert alert-success">Thank you for your feedback!</div><?php endif; ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Type</th>
                    <th>Purok</th>
                    <th>Status</th>
                    <th>Rating / Feedback</th>
                    <th>Date</th>
                    <th>Slip</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($data && $data->num_rows > 0): while ($row = $data->fetch_assoc()): 
                    $statusClass = strtolower(str_replace(' ', '-', $row['status'] ?? 'pending'));
                    if ($statusClass === 'in-progress') $statusClass = 'progress';
                    $rating = isset($row['rating']) ? (int)$row['rating'] : 0;
                    $feedback = isset($row['feedback']) ? trim($row['feedback']) : '';
                ?>
                <tr>
                    <td><strong><?= htmlspecialchars($row['incident_code']) ?></strong></td>
                    <td><?= htmlspecialchars($row['report_type']) ?></td>
                    <td><?= htmlspecialchars($row['purok'] ?: '-') ?></td>
                    <td><span class="badge badge-<?= $statusClass ?>"><?= htmlspecialchars($row['status'] ?? 'Pending') ?></span></td>
                    <td>
                        <?php if ($rating > 0): ?>
                        <span title="<?= htmlspecialchars($feedback) ?>"><?= str_repeat('★', $rating) . str_repeat('☆', 5 - $rating) ?> <?= $rating ?>/5</span>
                        <?php if ($feedback): ?><br><small style="color:#64748b;"><?= htmlspecialchars(substr($feedback, 0, 60)) ?><?= strlen($feedback) > 60 ? '…' : '' ?></small><?php endif; ?>
                        <?php else: ?>-
                        <?php endif; ?>
                    </td>
                    <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                    <td><a href="acknowledgement_slip.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-secondary" target="_blank">View / Print</a></td>
                    <td>
                        <?php if (($row['status'] ?? '') === 'Resolved'): ?>
                            <a href="view_before_after.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-secondary" style="margin-right:6px;">Before–After</a>
                            <?php if ($rating > 0): ?>
                            <span style="color:#64748b;">Feedback submitted</span>
                            <?php else: ?>
                            <a href="feedback.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-primary">Give Feedback</a>
                            <?php endif; ?>
                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="8" style="text-align:center; padding: 40px; color: #64748b;">No reports yet. <a href="report_incident.php">Report an incident</a></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
