<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['resident', 'user'])) {
    header("Location: ../auth/login.php");
    exit;
}
$id = (int)($_GET['id'] ?? 0);
$user_id = (int)$_SESSION['user_id'];
$inc = $conn->query("SELECT * FROM incidents WHERE id=$id AND user_id=$user_id");
if (!$inc || $inc->num_rows === 0) {
    header("Location: my_reports.php");
    exit;
}
$incident = $inc->fetch_assoc();
$before_photos = $conn->query("SELECT * FROM incident_photos WHERE incident_id=$id ORDER BY id");
$after_photos = $conn->query("SELECT * FROM incident_after_photos WHERE incident_id=$id ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Before–After - <?= htmlspecialchars($incident['incident_code']) ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .ba-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 20px; }
        .ba-box { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .ba-box h3 { margin: 0 0 12px; color: #0f172a; }
        .ba-box img { max-width: 100%; height: auto; border-radius: 8px; border: 1px solid #e2e8f0; margin-top: 8px; }
        @media (max-width: 700px) { .ba-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<div class="sidebar">
    <h3>Resident Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="report_incident.php">Report Incident</a>
    <a href="my_reports.php" class="active">My Reports</a>
    <a href="announcements.php">Announcements</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <a href="my_reports.php" class="btn btn-secondary" style="margin-bottom:16px;">← Back to My Reports</a>
    <div class="page-header">
        <h2>Before – After (proof na na-actionan)</h2>
        <p style="color:#64748b;">Incident <strong><?= htmlspecialchars($incident['incident_code']) ?></strong> — <?= htmlspecialchars($incident['report_type']) ?>. Read-only.</p>
    </div>
    <div class="ba-grid">
        <div class="ba-box">
            <h3>Before</h3>
            <p style="color:#64748b; font-size:0.9rem;">Photo na in-upload mo noong nag-report.</p>
            <?php if ($before_photos && $before_photos->num_rows > 0): while ($p = $before_photos->fetch_assoc()): ?>
            <img src="../<?= htmlspecialchars($p['photo_path']) ?>" alt="Before">
            <?php endwhile; else: ?><p style="color:#94a3b8;">Walang before photo</p><?php endif; ?>
        </div>
        <div class="ba-box">
            <h3>After</h3>
            <p style="color:#64748b; font-size:0.9rem;">Photo na in-upload ng admin kapag resolved.</p>
            <?php if ($after_photos && $after_photos->num_rows > 0): while ($p = $after_photos->fetch_assoc()): ?>
            <img src="../<?= htmlspecialchars($p['photo_path']) ?>" alt="After">
            <?php endwhile; else: ?><p style="color:#94a3b8;">Wala pang after photo</p><?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
