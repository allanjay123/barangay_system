<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['resident', 'user'])) {
    header("Location: ../auth/login.php");
    exit;
}
require_once "../config/notify.php";
$success = "";
$error = "";
$duplicates = [];
$form_data = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $type = $conn->real_escape_string(trim($_POST['report_type'] ?? ''));
    $desc = $conn->real_escape_string(trim($_POST['description'] ?? ''));
    $purok = $conn->real_escape_string(trim($_POST['purok'] ?? ''));
    $street = $conn->real_escape_string(trim($_POST['street'] ?? ''));
    $zone = $conn->real_escape_string(trim($_POST['zone'] ?? ''));
    $loc = $conn->real_escape_string(trim($_POST['location_text'] ?? ''));
    $lat = isset($_POST['lat']) && $_POST['lat'] !== '' ? (float)$_POST['lat'] : null;
    $lng = isset($_POST['lng']) && $_POST['lng'] !== '' ? (float)$_POST['lng'] : null;
    $user_id = (int)$_SESSION['user_id'];
    $confirm_duplicate = isset($_POST['confirm_duplicate']);
    $same_issue_id = isset($_POST['same_issue_id']) ? (int)$_POST['same_issue_id'] : 0;
    if (empty($type) || empty($desc)) {
        $error = "Report type and description are required.";
    } else {
        $dup_check = $purok !== '' ? $conn->query("SELECT id, incident_code, report_type, created_at FROM incidents WHERE purok='$purok' AND report_type='$type' AND status IN ('Pending','Assigned','In Progress') AND id != " . ($same_issue_id)) : false;
        if ($dup_check && $dup_check->num_rows > 0 && !$confirm_duplicate) {
            while ($d = $dup_check->fetch_assoc()) $duplicates[] = $d;
            $form_data = $_POST;
        } else {
        $code = "INC" . date("Ymd") . rand(100, 999);
        $incCols = [];
        $r = $conn->query("SHOW COLUMNS FROM incidents");
        while ($c = $r->fetch_assoc()) $incCols[] = $c['Field'];
        $hasStreet = in_array('street', $incCols);
        $hasZone = in_array('zone', $incCols);
        $hasLat = in_array('lat', $incCols);
        $cols = "incident_code, user_id, report_type, description, purok, location_text, status, created_at, updated_at";
        $vals = "'$code', $user_id, '$type', '$desc', '$purok', '$loc', 'Pending', NOW(), NOW()";
        if ($hasStreet) { $cols .= ", street"; $vals .= ", '$street'"; }
        if ($hasZone) { $cols .= ", zone"; $vals .= ", '$zone'"; }
        if ($hasLat) {
            $lat_sql = $lat !== null ? $lat : "NULL";
            $lng_sql = $lng !== null ? $lng : "NULL";
            $cols .= ", lat, lng";
            $vals .= ", $lat_sql, $lng_sql";
        }
        $conn->query("INSERT INTO incidents ($cols) VALUES ($vals)");
        $incident_id = $conn->insert_id;
        if (!empty($_FILES['photo']['name'])) {
            $uploads_dir = dirname(__DIR__) . "/uploads";
            if (!is_dir($uploads_dir)) mkdir($uploads_dir, 0755, true);
            $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION) ?: 'jpg';
            $filename = "inc_" . $incident_id . "_" . time() . "." . $ext;
            $path = "uploads/" . $filename;
            $full_path = dirname(__DIR__) . "/" . $path;
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $full_path)) {
                $photo_path = "uploads/" . $filename;
                $conn->query("INSERT INTO incident_photos (incident_id, photo_path) VALUES ($incident_id, '$photo_path')");
            }
        }
        create_notification($conn, 'admin', 'new_report', 'New report received', "Incident $code - $type", null, $incident_id);
            if ($same_issue_id > 0) {
                $conn->query("INSERT INTO incident_same_issue (incident_id, related_incident_id, marked_by_user) VALUES ($incident_id, $same_issue_id, $user_id)");
            }
            header("Location: acknowledgement_slip.php?id=" . $incident_id);
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Incident - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        #map { height: 320px; border-radius: 12px; margin-bottom: 16px; }
        .map-hint { font-size: 0.85rem; color: #64748b; margin-bottom: 8px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h3>Resident Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="report_incident.php" class="active">Report Incident</a>
    <a href="my_reports.php">My Reports</a>
    <a href="announcements.php">Announcements</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Report Incident</h2></div>
    <?php if (!empty($duplicates)): ?>
    <div class="alert alert-error">
        <strong>May existing report na sa area na ito.</strong><br>
        <?php foreach ($duplicates as $d): ?>
        • <?= htmlspecialchars($d['incident_code']) ?> (<?= htmlspecialchars($d['report_type']) ?>) — <?= date('M d, Y', strtotime($d['created_at'])) ?><br>
        <?php endforeach; ?>
        Pwede kang <strong>mag-continue reporting</strong> (new report) o i-mark bilang <strong>Same issue</strong> sa dropdown below.
    </div>
    <?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <div class="form-card">
        <form method="POST" enctype="multipart/form-data" id="reportForm">
            <?php if (!empty($duplicates)): ?>
            <input type="hidden" name="confirm_duplicate" value="1">
            <label>Mark as same issue (optional)</label>
            <select name="same_issue_id">
                <option value="0">— No (new report) —</option>
                <?php foreach ($duplicates as $d): ?><option value="<?= (int)$d['id'] ?>"><?= htmlspecialchars($d['incident_code']) ?></option><?php endforeach; ?>
            </select>
            <p style="color:#64748b; font-size:0.9rem;">Re-fill the form below and submit again. If you had a photo, please select it again.</p>
            <?php endif; ?>
            <label>Report Type</label>
            <select name="report_type" required>
                <option value="">-- Select Type --</option>
                <option value="Sirang kalsada" <?= ($form_data['report_type'] ?? '') === 'Sirang kalsada' ? 'selected' : '' ?>>Sirang kalsada</option>
                <option value="Sirang ilaw" <?= ($form_data['report_type'] ?? '') === 'Sirang ilaw' ? 'selected' : '' ?>>Sirang ilaw</option>
                <option value="Basura" <?= ($form_data['report_type'] ?? '') === 'Basura' ? 'selected' : '' ?>>Basura</option>
                <option value="Safety issue" <?= ($form_data['report_type'] ?? '') === 'Safety issue' ? 'selected' : '' ?>>Safety issue</option>
                <option value="Flooding" <?= ($form_data['report_type'] ?? '') === 'Flooding' ? 'selected' : '' ?>>Flooding</option>
                <option value="Noise complaint" <?= ($form_data['report_type'] ?? '') === 'Noise complaint' ? 'selected' : '' ?>>Noise complaint</option>
                <option value="Other" <?= ($form_data['report_type'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
            </select>
            <label>Description</label>
            <textarea name="description" rows="4" placeholder="Describe the incident in detail..." required><?= htmlspecialchars($form_data['description'] ?? '') ?></textarea>
            <label>Purok</label>
            <input type="text" name="purok" placeholder="e.g. Purok 1" value="<?= htmlspecialchars($form_data['purok'] ?? '') ?>">
            <label>Street</label>
            <input type="text" name="street" placeholder="Street name" value="<?= htmlspecialchars($form_data['street'] ?? '') ?>">
            <label>Zone</label>
            <input type="text" name="zone" placeholder="e.g. Zone 1" value="<?= htmlspecialchars($form_data['zone'] ?? '') ?>">
            <label>Location / Landmark</label>
            <input type="text" name="location_text" id="location_text" placeholder="Nearby landmark" value="<?= htmlspecialchars($form_data['location_text'] ?? '') ?>">
            <label>Pin location on map (click to set)</label>
            <p class="map-hint">Click on the map to mark the exact location of the incident.</p>
            <div id="map"></div>
            <input type="hidden" name="lat" id="lat" value="<?= htmlspecialchars($form_data['lat'] ?? '') ?>">
            <input type="hidden" name="lng" id="lng" value="<?= htmlspecialchars($form_data['lng'] ?? '') ?>">
            <label>Photo (optional)</label>
            <input type="file" name="photo" accept="image/*">
            <button type="submit" name="submit" class="btn btn-primary">Submit Report</button>
        </form>
    </div>
</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
(function() {
    var defaultLat = 14.5995, defaultLng = 120.9842;
    var map = L.map('map').setView([defaultLat, defaultLng], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap' }).addTo(map);
    var marker = null;
    function placeMarker(latlng) {
        if (marker) map.removeLayer(marker);
        marker = L.marker(latlng).addTo(map);
        document.getElementById('lat').value = latlng.lat.toFixed(6);
        document.getElementById('lng').value = latlng.lng.toFixed(6);
    }
    map.on('click', function(e) { placeMarker(e.latlng); });
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(p) {
            var ll = [p.coords.latitude, p.coords.longitude];
            map.setView(ll, 16);
            placeMarker(L.latLng(ll));
        });
    }
})();
</script>
</body>
</html>
