<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}
$id = (int)($_GET['id'] ?? 0);
$is_admin = isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin', 'staff']);
$inc = $conn->query("SELECT i.*, u.full_name as reporter FROM incidents i LEFT JOIN users u ON i.user_id=u.id WHERE i.id=$id");
if (!$inc || $inc->num_rows === 0) {
    header("Location: " . ($is_admin ? "../admin/manage_incidents.php" : "my_reports.php"));
    exit;
}
$incident = $inc->fetch_assoc();
if (!$is_admin && (int)$incident['user_id'] !== (int)$_SESSION['user_id']) {
    header("Location: my_reports.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acknowledgement Slip - <?= htmlspecialchars($incident['incident_code']) ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        @media print { .no-print { display: none !important; } body { background: #fff; } .slip { box-shadow: none; border: 1px solid #000; } }
        .slip { max-width: 500px; margin: 24px auto; background: #fff; padding: 32px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); border: 2px solid #0f766e; }
        .slip h1 { margin: 0 0 8px; font-size: 1.25rem; color: #0f172a; }
        .slip .sub { margin-bottom: 24px; color: #64748b; font-size: 0.9rem; }
        .slip table { width: 100%; border-collapse: collapse; }
        .slip th, .slip td { padding: 10px 0; text-align: left; border-bottom: 1px solid #e2e8f0; }
        .slip th { color: #64748b; font-weight: 600; width: 140px; }
        .slip-buttons { margin-top: 24px; display: flex; gap: 12px; flex-wrap: wrap; }
    </style>
</head>
<body>
<div class="no-print" style="padding: 16px;">
    <a href="<?= $is_admin ? '../admin/manage_incidents.php' : 'my_reports.php' ?>" class="btn btn-secondary">← Back</a>
</div>
<div class="slip" id="slip">
    <h1>Barangay Incident Report</h1>
    <p class="sub">Acknowledgement Slip – Official Reference</p>
    <table>
        <tr><th>Incident ID</th><td><strong><?= htmlspecialchars($incident['incident_code']) ?></strong></td></tr>
        <tr><th>Date & time reported</th><td><?= date('F d, Y \a\t g:i A', strtotime($incident['created_at'])) ?></td></tr>
        <tr><th>Report type</th><td><?= htmlspecialchars($incident['report_type']) ?></td></tr>
        <tr><th>Location / Purok</th><td><?= htmlspecialchars($incident['purok'] ?? '-') ?><?= !empty($incident['street']) ? ' • ' . htmlspecialchars($incident['street']) : '' ?><?= !empty($incident['zone']) ? ' • Zone ' . htmlspecialchars($incident['zone']) : '' ?></td></tr>
        <tr><th>Reporter</th><td><?= htmlspecialchars($incident['reporter'] ?? '-') ?></td></tr>
    </table>
    <p style="margin-top: 20px; font-size: 0.85rem; color: #64748b;">Present this slip at the Barangay Hall as proof of report. Keep for your records.</p>
</div>
<div class="no-print slip-buttons" style="justify-content: center;">
    <button type="button" class="btn btn-primary" onclick="window.print();">Print / Save as PDF</button>
    <a href="acknowledgement_slip.php?id=<?= $id ?>&print=1" class="btn btn-secondary" target="_blank">Download PDF</a>
</div>
<script>
if (window.location.search.indexOf('print=1') !== -1) {
    window.onload = function() { window.print(); };
}
</script>
</body>
</html>
