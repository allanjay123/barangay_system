<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['resident', 'user'])) {
    header("Location: ../auth/login.php");
    exit;
}
if (!isset($_GET['id'])) {
    header("Location: my_reports.php");
    exit;
}
$id = (int)$_GET['id'];
$user_id = (int)$_SESSION['user_id'];
$inc = $conn->query("SELECT * FROM incidents WHERE id=$id AND user_id=$user_id AND status='Resolved'");
if (!$inc || $inc->num_rows === 0) {
    header("Location: my_reports.php");
    exit;
}
$incident = $inc->fetch_assoc();
if (!empty($incident['rating']) && (int)$incident['rating'] > 0) {
    header("Location: my_reports.php");
    exit;
}
$success = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $rating = (int)($_POST['rating'] ?? 0);
    $feedback = $conn->real_escape_string(trim($_POST['feedback'] ?? ''));
    if ($rating >= 1 && $rating <= 5) {
        $conn->query("UPDATE incidents SET rating=$rating, feedback='$feedback' WHERE id=$id");
        $success = "Feedback submitted!";
        header("Location: my_reports.php?feedback=1");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Give Feedback - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Resident Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="report_incident.php">Report Incident</a>
    <a href="my_reports.php">My Reports</a>
    <a href="announcements.php">Announcements</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Give Feedback</h2></div>
    <div class="form-card" style="max-width: 500px;">
        <p style="color: #64748b;">Incident: <strong><?= htmlspecialchars($incident['incident_code']) ?></strong></p>
        <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
        <form method="POST">
            <label>Rating (1-5 stars)</label>
            <input type="number" name="rating" min="1" max="5" value="5" required>
            <label>Comment</label>
            <textarea name="feedback" rows="4" placeholder="How was the resolution?"></textarea>
            <button type="submit" name="submit" class="btn btn-primary">Submit Feedback</button>
            <a href="my_reports.php" class="btn btn-secondary" style="margin-left: 10px;">Cancel</a>
        </form>
    </div>
</div>
</body>
</html>
