<?php
/**
 * One-time setup: Create admin user
 * Run once then delete or restrict access
 * Default: admin / admin123
 */
require_once "../config/db.php";

$created = false;
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['full_name'] ?? '');
    $pass = $_POST['password'] ?? '';
    if (strlen($name) >= 2 && strlen($pass) >= 6) {
        $check = $conn->query("SELECT id FROM users WHERE full_name='$name' AND role='admin'");
        if ($check && $check->num_rows > 0) {
            $error = "Admin already exists.";
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $name = $conn->real_escape_string($name);
            $conn->query("INSERT INTO users (full_name, email, password, role, is_anonymous, created_at) VALUES ('$name', NULL, '$hash', 'admin', 0, NOW())");
            $created = true;
        }
    } else {
        $error = "Name (min 2) and password (min 6) required.";
    }
}
$hasAdmin = $conn->query("SELECT id FROM users WHERE role='admin'")->num_rows > 0;
?>
<!DOCTYPE html>
<html>
<head><title>Create Admin</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body style="display:flex; align-items:center; justify-content:center; min-height:100vh; background:#f1f5f9;">
<div class="form-card" style="max-width:400px;">
<h2>Create Admin Account</h2>
<?php if ($created): ?><div class="alert alert-success">Admin created! <a href="../auth/login.php">Login</a></div>
<?php elseif ($hasAdmin && !$created): ?><p style="color:#64748b;">Admin exists. <a href="../auth/login.php">Login</a></p>
<?php else: ?>
<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="POST">
<input type="text" name="full_name" placeholder="Full Name" value="Admin" required>
<input type="password" name="password" placeholder="Password (min 6)" required>
<button type="submit" class="btn btn-primary">Create Admin</button>
</form>
<?php endif; ?>
</div>
</body>
</html>
