<?php
/**
 * Audit log helper. Requires $conn and $_SESSION['user_id'].
 */
function audit_log($conn, $action, $entity_type = null, $entity_id = null, $details = null) {
    $t = @$conn->query("SHOW TABLES LIKE 'audit_logs'");
    if (!$t || $t->num_rows === 0) return false;
    $user_id = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    $action = $conn->real_escape_string($action);
    $entity_type = $entity_type ? "'" . $conn->real_escape_string($entity_type) . "'" : "NULL";
    $entity_id = $entity_id !== null ? (int)$entity_id : "NULL";
    $details = $details ? "'" . $conn->real_escape_string(substr($details, 0, 500)) . "'" : "NULL";
    $cols = "user_id, action, created_at";
    $vals = "$user_id, '$action', NOW()";
    $c = @$conn->query("SHOW COLUMNS FROM audit_logs");
    if ($c) {
        $col_list = [];
        while ($r = $c->fetch_assoc()) $col_list[] = strtolower($r['Field']);
        if (in_array('entity_type', $col_list)) { $cols .= ", entity_type"; $vals .= ", $entity_type"; }
        if (in_array('entity_id', $col_list)) { $cols .= ", entity_id"; $vals .= ", $entity_id"; }
        if (in_array('details', $col_list)) { $cols .= ", details"; $vals .= ", $details"; }
    }
    return @$conn->query("INSERT INTO audit_logs ($cols) VALUES ($vals)");
}
