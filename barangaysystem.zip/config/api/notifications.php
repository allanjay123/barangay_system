<?php
header('Content-Type: application/json');
require_once "../config/init.php";

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    echo json_encode(['ok' => false, 'notifications' => []]);
    exit;
}

$role = $_SESSION['role'];
$user_id = (int)$_SESSION['user_id'];
$t = $conn->query("SHOW TABLES LIKE 'notifications'");
if (!$t || $t->num_rows === 0) {
    echo json_encode(['ok' => true, 'notifications' => []]);
    exit;
}

// Mark as read
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['read'])) {
    $id = (int)$_GET['read'];
    $for_role = $role === 'admin' || $role === 'staff' ? 'admin' : 'resident';
    $conn->query("UPDATE notifications SET read_at=NOW() WHERE id=$id AND (user_id=$user_id OR (for_role='$for_role' AND user_id IS NULL))");
    echo json_encode(['ok' => true]);
    exit;
}

// Fetch unread (and recent) for current user/role
$for_role = ($role === 'admin' || $role === 'staff') ? 'admin' : 'resident';
$q = "SELECT id, type, title, message, related_id, created_at FROM notifications WHERE read_at IS NULL AND for_role='$for_role' AND (user_id IS NULL OR user_id=$user_id) ORDER BY created_at DESC LIMIT 30";
$res = $conn->query($q);
$list = [];
while ($row = $res->fetch_assoc()) $list[] = $row;
echo json_encode(['ok' => true, 'notifications' => $list]);
