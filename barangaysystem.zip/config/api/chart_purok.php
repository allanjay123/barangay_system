<?php
header('Content-Type: application/json');
require_once "../config/init.php";

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    echo json_encode(['ok' => false, 'labels' => [], 'data' => []]);
    exit;
}

// Group by purok (barangay area). Use purok if not empty, else "Unspecified" so we still see count
$res = @$conn->query("SELECT COALESCE(NULLIF(TRIM(purok),''), 'Unspecified') AS purok, COUNT(*) AS cnt FROM incidents GROUP BY COALESCE(NULLIF(TRIM(purok),''), 'Unspecified') ORDER BY cnt DESC LIMIT 20");
$labels = [];
$data = [];
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $labels[] = $row['purok'];
        $data[] = (int)$row['cnt'];
    }
}
// If no rows (no incidents), return one bar so chart can show "No data"
if (empty($labels)) {
    $labels = ['No reports yet'];
    $data = [0];
}
echo json_encode(['ok' => true, 'labels' => $labels, 'data' => $data]);
