<?php
header('Content-Type: application/json');
require_once "../config/init.php";

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['ok' => false]);
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$role = $_SESSION['role'] ?? '';

if ($role === 'admin' || $role === 'staff') {
    $total = $conn->query("SELECT COUNT(*) as c FROM incidents")->fetch_assoc()['c'] ?? 0;
    $pending = $conn->query("SELECT COUNT(*) as c FROM incidents WHERE status='Pending'")->fetch_assoc()['c'] ?? 0;
    $resolved = $conn->query("SELECT COUNT(*) as c FROM incidents WHERE status='Resolved'")->fetch_assoc()['c'] ?? 0;
    echo json_encode(['ok' => true, 'total' => (int)$total, 'pending' => (int)$pending, 'resolved' => (int)$resolved]);
} else {
    $total = $conn->query("SELECT COUNT(*) as c FROM incidents WHERE user_id=$user_id")->fetch_assoc()['c'] ?? 0;
    $resolved = $conn->query("SELECT COUNT(*) as c FROM incidents WHERE user_id=$user_id AND status='Resolved'")->fetch_assoc()['c'] ?? 0;
    $pending = $conn->query("SELECT COUNT(*) as c FROM incidents WHERE user_id=$user_id AND status='Pending'")->fetch_assoc()['c'] ?? 0;
    echo json_encode(['ok' => true, 'total' => (int)$total, 'pending' => (int)$pending, 'resolved' => (int)$resolved]);
}
