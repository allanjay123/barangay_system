<?php
/**
 * Auto-migration: add missing columns and notifications table.
 */
if (!isset($conn)) return;
$r = @$conn->query("SHOW COLUMNS FROM incidents");
if (!$r) return;
$existing = [];
while ($row = $r->fetch_assoc()) $existing[] = $row['Field'];
$add = [
    'street'  => "ADD COLUMN street VARCHAR(255) NULL",
    'zone'    => "ADD COLUMN zone VARCHAR(100) NULL",
    'lat'     => "ADD COLUMN lat DECIMAL(10,8) NULL",
    'lng'     => "ADD COLUMN lng DECIMAL(11,8) NULL",
    'rating'  => "ADD COLUMN rating INT NULL",
    'feedback'=> "ADD COLUMN feedback TEXT NULL",
];
foreach ($add as $col => $sql) {
    if (!in_array($col, $existing)) {
        @$conn->query("ALTER TABLE incidents " . $sql);
    }
}
$u = @$conn->query("SHOW COLUMNS FROM users");
if ($u) {
    $ucols = [];
    while ($row = $u->fetch_assoc()) $ucols[] = strtolower($row['Field']);
    if (!in_array('email', $ucols)) {
        @$conn->query("ALTER TABLE users ADD COLUMN email VARCHAR(255) NULL");
    }
}
$conn->query("CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  for_role VARCHAR(20) NOT NULL,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT,
  related_id INT NULL,
  read_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_role (user_id, for_role),
  INDEX idx_read (read_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS incident_after_photos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT NOT NULL,
  photo_path VARCHAR(500) NOT NULL,
  uploaded_by INT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_incident (incident_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS incident_merges (
  id INT AUTO_INCREMENT PRIMARY KEY,
  primary_incident_id INT NOT NULL,
  merged_incident_id INT NOT NULL,
  merged_by INT NULL,
  reason VARCHAR(500) NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS incident_same_issue (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT NOT NULL,
  related_incident_id INT NOT NULL,
  marked_by_user INT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS incident_keep_separate (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT NOT NULL,
  related_incident_id INT NOT NULL,
  reason VARCHAR(500) NULL,
  decided_by INT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

if (!in_array('estimated_cost', $existing)) @$conn->query("ALTER TABLE incidents ADD COLUMN estimated_cost DECIMAL(12,2) NULL");
if (!in_array('actual_cost', $existing)) @$conn->query("ALTER TABLE incidents ADD COLUMN actual_cost DECIMAL(12,2) NULL");

$audit = @$conn->query("SHOW TABLES LIKE 'audit_logs'");
if ($audit && $audit->num_rows > 0) {
    $ac = @$conn->query("SHOW COLUMNS FROM audit_logs");
    $acols = [];
    if ($ac) while ($ar = $ac->fetch_assoc()) $acols[] = strtolower($ar['Field']);
    if (!in_array('entity_type', $acols)) @$conn->query("ALTER TABLE audit_logs ADD COLUMN entity_type VARCHAR(50) NULL");
    if (!in_array('entity_id', $acols)) @$conn->query("ALTER TABLE audit_logs ADD COLUMN entity_id INT NULL");
    if (!in_array('details', $acols)) @$conn->query("ALTER TABLE audit_logs ADD COLUMN details VARCHAR(500) NULL");
} else {
    $conn->query("CREATE TABLE IF NOT EXISTS audit_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NULL,
      action VARCHAR(100) NOT NULL,
      entity_type VARCHAR(50) NULL,
      entity_id INT NULL,
      details VARCHAR(500) NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_created (created_at),
      INDEX idx_entity (entity_type, entity_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
