<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "barangay_system";
$port = 3307; // ← add this

$conn = new mysqli($host, $user, $pass, $db, $port);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
