<?php
/**
 * Create a notification. $conn must be available.
 */
function create_notification($conn, $for_role, $type, $title, $message = null, $user_id = null, $related_id = null) {
    $t = $conn->query("SHOW TABLES LIKE 'notifications'");
    if (!$t || $t->num_rows === 0) return false;
    $for_role = $conn->real_escape_string($for_role);
    $type = $conn->real_escape_string($type);
    $title = $conn->real_escape_string($title);
    $message = $message ? "'" . $conn->real_escape_string($message) . "'" : "NULL";
    $user_id = $user_id !== null ? (int)$user_id : "NULL";
    $related_id = $related_id !== null ? (int)$related_id : "NULL";
    return $conn->query("INSERT INTO notifications (user_id, for_role, type, title, message, related_id) VALUES ($user_id, '$for_role', '$type', '$title', $message, $related_id)");
}
