# Barangay Incident Reporting System

Professional barangay management system for incident reporting, announcements, feedback, and notifications.

## Setup

1. **Database**: Ensure MySQL is running (port 3307 in `config/db.php`; XAMPP default is 3306).

2. **Create Admin**: Visit `setup/create_admin.php` to create your first admin account. Delete or protect this folder after use.

3. **New features (street, zone, map, notifications)**: Run **`install_migration.php`** once in the browser:  
   `http://localhost/barangay_system/install_migration.php`  
   This adds columns to `incidents` (street, zone, lat, lng) and creates the `notifications` table.

## Features

### Residents
- **Register & Login** – Login with full name or email after registering.
- **Report incidents** – Type, description, purok, **street**, **zone**, **map pin** (click to set location), photo.
- **My Reports** – View status; **Rating / Feedback** column; give feedback when resolved.
- **Dashboard** – **Realtime** stats (refresh every 30s), **notifications** (e.g. “On the way”, “Report resolved”).
- **Download / Install Web App** – PWA: “Install” or “Add to Home Screen” when supported.

### Admin
- **Dashboard** – Stats + **bar graph** (reports by purok/barangay), **notifications** for new reports.
- **Manage Incidents** – **Street**, **Zone**, **View Map** (see user’s pin); status update sends notification to user.
- **Feedback Monitoring** – View citizens’ **ratings and comments** on resolved reports.
- **Announcements, Staff, Analytics** – Unchanged.

### Staff
- Manage incidents (with street, zone, map link); no feedback page.

## File Structure

```
barangay_system/
├── api/              - notifications.php, dashboard_stats.php, chart_purok.php
├── auth/             - login, register, logout
├── user/             - dashboard (realtime, notifs, PWA), report (map), my_reports, feedback, announcements
├── admin/             - dashboard (bar chart, notifs), manage_incidents (map), feedback_monitoring, ...
├── config/           - db, init, notify
├── assets/css/       - styles
├── uploads/          - incident photos
├── manifest.json     - PWA manifest
├── sw.js             - Service worker
├── install_migration.php  - Run once for new DB columns & notifications table
└── database/         - schema.sql, migrations_v2.sql
```
