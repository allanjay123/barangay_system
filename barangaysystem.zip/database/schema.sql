-- Barangay System - Database Schema & Updates
-- Run this if you need to fix or update tables

-- Ensure users table has correct structure (email nullable)
ALTER TABLE users MODIFY COLUMN email VARCHAR(255) NULL;
ALTER TABLE users MODIFY COLUMN role VARCHAR(50) DEFAULT 'resident';

-- Ensure incidents has default status
ALTER TABLE incidents MODIFY COLUMN status VARCHAR(50) DEFAULT 'Pending';

-- Sample: Create first admin (password: admin123) - run manually after hashing
-- INSERT INTO users (full_name, email, password, role, is_anonymous, created_at) 
-- VALUES ('Admin', 'admin@barangay.gov', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 0, NOW());
