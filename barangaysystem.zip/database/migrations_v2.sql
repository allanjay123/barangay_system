-- Barangay System - New features: street, zone, map, notifications
-- Run in phpMyAdmin (SQL tab). If column exists, skip that line or run install_migration.php once.

ALTER TABLE incidents ADD COLUMN street VARCHAR(255) NULL AFTER purok;
ALTER TABLE incidents ADD COLUMN zone VARCHAR(100) NULL AFTER street;
ALTER TABLE incidents ADD COLUMN lat DECIMAL(10,8) NULL AFTER location_text;
ALTER TABLE incidents ADD COLUMN lng DECIMAL(11,8) NULL AFTER lat;

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  for_role VARCHAR(20) NOT NULL,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT,
  related_id INT NULL,
  read_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_role (user_id, for_role),
  INDEX idx_read (read_at),
  INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
