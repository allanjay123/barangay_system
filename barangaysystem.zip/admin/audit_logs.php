<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
$t = @$conn->query("SHOW TABLES LIKE 'audit_logs'");
if (!$t || $t->num_rows === 0) {
    $logs = [];
} else {
    $res = $conn->query("SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.created_at DESC LIMIT 500");
    $logs = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Logs - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php">Incidents</a>
    <a href="duplicate_incidents.php">Duplicates</a>
    <a href="announcements.php">Announcements</a>
    <a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php">Analytics</a>
    <a href="budget_report.php">Budget</a>
    <a href="audit_logs.php" class="active">Audit Logs</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Audit Logs</h2></div>
    <p style="color:#64748b;">All important actions are logged for audit trail.</p>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Date & time</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Entity</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $row): ?>
                <tr>
                    <td><?= date('M d, Y H:i', strtotime($row['created_at'])) ?></td>
                    <td><?= htmlspecialchars($row['full_name'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['action'] ?? '-') ?></td>
                    <td><?= htmlspecialchars(($row['entity_type'] ?? '') . ($row['entity_id'] ? ' #' . $row['entity_id'] : '')) ?></td>
                    <td><?= htmlspecialchars($row['details'] ?? '') ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($logs)): ?>
                <tr><td colspan="5" style="text-align:center;padding:40px;">No audit logs yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
