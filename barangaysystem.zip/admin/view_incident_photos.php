<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'staff'])) {
    header("Location: ../auth/login.php");
    exit;
}
$id = (int)($_GET['id'] ?? 0);
$inc = $conn->query("SELECT i.*, u.full_name as reporter FROM incidents i LEFT JOIN users u ON i.user_id=u.id WHERE i.id=$id");
if (!$inc || $inc->num_rows === 0) {
    header("Location: manage_incidents.php");
    exit;
}
$incident = $inc->fetch_assoc();
$photos = $conn->query("SELECT id, photo_path FROM incident_photos WHERE incident_id=$id ORDER BY id");
$base_url = "../"; // from admin folder, uploads are at ../uploads/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photos - <?= htmlspecialchars($incident['incident_code']) ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; margin-top: 20px; }
        .photo-item { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .photo-item img { width: 100%; height: 200px; object-fit: cover; display: block; cursor: pointer; }
        .photo-item img:hover { opacity: 0.95; }
        .photo-item a { display: block; padding: 8px 12px; font-size: 0.85rem; color: #64748b; text-decoration: none; }
        .back-link { display: inline-block; margin-bottom: 16px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h3><?= $_SESSION['role'] === 'admin' ? 'Admin' : 'Staff' ?> Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php" class="active">Incidents</a>
    <a href="announcements.php">Announcements</a>
    <?php if ($_SESSION['role'] === 'admin'): ?><a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php">Analytics</a><?php endif; ?>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <a href="manage_incidents.php" class="btn btn-secondary back-link">← Back to Incidents</a>
    <div class="page-header">
        <h2>Photos submitted by user</h2>
        <p style="color:#64748b; margin: 4px 0 0;">Incident: <strong><?= htmlspecialchars($incident['incident_code']) ?></strong> — <?= htmlspecialchars($incident['report_type']) ?> (<?= htmlspecialchars($incident['reporter'] ?? '-') ?>)</p>
    </div>
    <?php if ($photos && $photos->num_rows > 0): ?>
    <div class="photo-grid">
        <?php while ($p = $photos->fetch_assoc()): 
            $path = $p['photo_path'];
            if (strpos($path, 'uploads/') === 0) {
                $img_src = $base_url . $path;
            } else {
                $img_src = $base_url . (strpos($path, '../') === 0 ? substr($path, 3) : 'uploads/' . basename($path));
            }
        ?>
        <div class="photo-item">
            <a href="<?= htmlspecialchars($img_src) ?>" target="_blank" title="Open full size">
                <img src="<?= htmlspecialchars($img_src) ?>" alt="Incident photo" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22><rect fill=%22%23f1f5f9%22 width=%22200%22 height=%22200%22/><text x=%2250%25%22 y=%2250%25%22 fill=%22%2394a3b8%22 text-anchor=%22middle%22 dy=%22.3em%22>Image not found</text></svg>';">
            </a>
            <a href="<?= htmlspecialchars($img_src) ?>" target="_blank">Open full size</a>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <div class="card" style="display:block;"><p style="margin:0; color:#64748b;">No photos submitted for this incident.</p></div>
    <?php endif; ?>
</div>
</body>
</html>
