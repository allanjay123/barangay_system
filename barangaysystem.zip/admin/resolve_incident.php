<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'staff'])) {
    header("Location: ../auth/login.php");
    exit;
}
require_once "../config/notify.php";
require_once "../config/audit.php";
$id = (int)($_GET['id'] ?? 0);
$inc = $conn->query("SELECT i.*, u.full_name as reporter FROM incidents i LEFT JOIN users u ON i.user_id=u.id WHERE i.id=$id");
if (!$inc || $inc->num_rows === 0) {
    header("Location: manage_incidents.php");
    exit;
}
$incident = $inc->fetch_assoc();
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resolve'])) {
    if (empty($_FILES['after_photo']['name'])) {
        $error = "After photo is required before marking as Resolved. Please upload proof photo.";
    } else {
        $uploads_dir = dirname(__DIR__) . "/uploads";
        if (!is_dir($uploads_dir)) mkdir($uploads_dir, 0755, true);
        $ext = pathinfo($_FILES['after_photo']['name'], PATHINFO_EXTENSION) ?: 'jpg';
        $filename = "after_" . $id . "_" . time() . "." . $ext;
        $path = "uploads/" . $filename;
        $full_path = dirname(__DIR__) . "/" . $path;
        if (move_uploaded_file($_FILES['after_photo']['tmp_name'], $full_path)) {
            $uid = (int)$_SESSION['user_id'];
            $conn->query("INSERT INTO incident_after_photos (incident_id, photo_path, uploaded_by) VALUES ($id, '$path', $uid)");
            $conn->query("UPDATE incidents SET status='Resolved', updated_at=NOW() WHERE id=$id");
            if ((int)$incident['user_id'] > 0) {
                create_notification($conn, 'resident', 'status_update', 'Report resolved', "Your report has been resolved. You may give feedback.", (int)$incident['user_id'], $id);
            }
            audit_log($conn, 'incident_resolved', 'incident', $id, 'After photo uploaded');
            $success = "Incident marked as Resolved. After photo saved.";
            header("Location: manage_incidents.php?resolved=1");
            exit;
        } else {
            $error = "Failed to upload photo.";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_after_photo'])) {
    if (!empty($_FILES['after_photo']['name'])) {
        $uploads_dir = dirname(__DIR__) . "/uploads";
        if (!is_dir($uploads_dir)) mkdir($uploads_dir, 0755, true);
        $ext = pathinfo($_FILES['after_photo']['name'], PATHINFO_EXTENSION) ?: 'jpg';
        $filename = "after_" . $id . "_" . time() . "." . $ext;
        $path = "uploads/" . $filename;
        $full_path = dirname(__DIR__) . "/" . $path;
        if (move_uploaded_file($_FILES['after_photo']['tmp_name'], $full_path)) {
            $uid = (int)$_SESSION['user_id'];
            $conn->query("INSERT INTO incident_after_photos (incident_id, photo_path, uploaded_by) VALUES ($id, '$path', $uid)");
            audit_log($conn, 'after_photo_added', 'incident', $id, 'Additional after photo');
            $success = "After photo added.";
        }
    }
}

$after_photos = $conn->query("SELECT * FROM incident_after_photos WHERE incident_id=$id ORDER BY created_at DESC");
$before_photos = $conn->query("SELECT * FROM incident_photos WHERE incident_id=$id ORDER BY id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resolve Incident - <?= htmlspecialchars($incident['incident_code']) ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php" class="active">Incidents</a>
    <a href="announcements.php">Announcements</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <a href="manage_incidents.php" class="btn btn-secondary" style="margin-bottom:16px;">← Back</a>
    <div class="page-header"><h2>Mark as Resolved (upload after photo)</h2></div>
    <p style="color:#64748b;">Incident <strong><?= htmlspecialchars($incident['incident_code']) ?></strong> — <?= htmlspecialchars($incident['report_type']) ?>. Proof photo is required.</p>
    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

    <?php if (($incident['status'] ?? '') !== 'Resolved'): ?>
    <div class="form-card" style="margin-bottom:24px;">
        <h3>Upload "After" photo (required to resolve)</h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="after_photo" accept="image/*" required>
            <button type="submit" name="resolve" class="btn btn-primary">Upload & Mark as Resolved</button>
        </form>
    </div>
    <?php else: ?>
    <div class="form-card" style="margin-bottom:24px;">
        <h3>Add another "After" photo (optional)</h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="after_photo" accept="image/*">
            <button type="submit" name="add_after_photo" class="btn btn-secondary">Add After Photo</button>
        </form>
    </div>
    <?php endif; ?>

    <h3 style="margin-top:24px;">Before (user) vs After (admin)</h3>
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-top:12px;">
        <div>
            <strong>Before</strong>
            <?php if ($before_photos && $before_photos->num_rows > 0): while ($p = $before_photos->fetch_assoc()): ?>
            <div style="margin-top:8px;"><img src="../<?= htmlspecialchars($p['photo_path']) ?>" alt="Before" style="max-width:100%; height:auto; border-radius:8px; border:1px solid #e2e8f0;"></div>
            <?php endwhile; else: ?><p style="color:#94a3b8;">No before photo</p><?php endif; ?>
        </div>
        <div>
            <strong>After</strong>
            <?php if ($after_photos && $after_photos->num_rows > 0): while ($p = $after_photos->fetch_assoc()): ?>
            <div style="margin-top:8px;"><img src="../<?= htmlspecialchars($p['photo_path']) ?>" alt="After" style="max-width:100%; height:auto; border-radius:8px; border:1px solid #e2e8f0;"></div>
            <?php endwhile; else: ?><p style="color:#94a3b8;">No after photo yet</p><?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
