<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
$totalInc = $conn->query("SELECT COUNT(*) as total FROM incidents")->fetch_assoc()['total'] ?? 0;
$totalUsers = $conn->query("SELECT COUNT(*) as total FROM users WHERE role IN ('resident','user')")->fetch_assoc()['total'] ?? 0;
$totalStaff = $conn->query("SELECT COUNT(*) as total FROM staff_accounts")->fetch_assoc()['total'] ?? 0;
$pending = $conn->query("SELECT COUNT(*) as t FROM incidents WHERE status='Pending'")->fetch_assoc()['t'] ?? 0;
$resolved = $conn->query("SELECT COUNT(*) as t FROM incidents WHERE status='Resolved'")->fetch_assoc()['t'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Barangay System</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<!-- Notifications: fixed top-right so always visible -->
<div id="adminNotifWrap" style="position:fixed; top:16px; right:20px; z-index:9999;">
    <div style="position:relative; display:inline-block;">
        <span id="notifCount" class="notif-badge" style="display:none;">0</span>
        <button type="button" id="notifBtn" class="btn btn-secondary" style="padding:8px 14px;">🔔 Notifications</button>
        <div id="notifDropdown" class="notif-dropdown" style="display:none;"></div>
    </div>
</div>

<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php" class="active">Dashboard</a>
    <a href="manage_incidents.php">Incidents</a>
    <a href="duplicate_incidents.php">Duplicates</a>
    <a href="announcements.php">Announcements</a>
    <a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php">Analytics</a>
    <a href="budget_report.php">Budget</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header">
        <h2>Dashboard</h2>
        <p style="color: #64748b; margin: 4px 0 0;">Welcome, <?= htmlspecialchars($_SESSION['fullname']) ?></p>
    </div>
    <div id="statsRow">
        <div class="card"><h3>Total Incidents</h3><h1><?= $totalInc ?></h1></div>
        <div class="card"><h3>Residents</h3><h1><?= $totalUsers ?></h1></div>
        <div class="card"><h3>Staff</h3><h1><?= $totalStaff ?></h1></div>
        <div class="card"><h3>Pending</h3><h1><?= $pending ?></h1></div>
        <div class="card"><h3>Resolved</h3><h1><?= $resolved ?></h1></div>
    </div>
    <div class="card" style="display:block; width:100%; max-width: 900px; margin-top: 24px;">
        <h3 style="margin: 0 0 20px; color: #0f172a; font-size: 1.1rem;">Reports by Purok / Barangay</h3>
        <p style="margin: -10px 0 16px; color: #64748b; font-size: 0.9rem;">Which area has the most reports.</p>
        <div style="min-height: 300px;">
            <canvas id="purokChart" height="300"></canvas>
        </div>
    </div>
</div>
<style>
#adminNotifWrap { position: fixed !important; top: 16px !important; right: 20px !important; z-index: 9999 !important; }
.notif-badge { position: absolute; top: -6px; right: -6px; background: #dc2626; color: #fff; font-size: 0.75rem; min-width: 20px; height: 20px; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; }
.notif-dropdown { position: absolute; top: 100%; right: 0; margin-top: 6px; background: #fff; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); min-width: 320px; max-height: 400px; overflow-y: auto; z-index: 10000; border: 1px solid #e2e8f0; }
.notif-item { padding: 14px 18px; border-bottom: 1px solid #f1f5f9; cursor: pointer; }
.notif-item:hover { background: #f8fafc; }
.notif-item small { color: #94a3b8; }
</style>
<script>
(function() {
    var base = '../';
    function fetchNotifs() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', base + 'api/notifications.php');
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var d = JSON.parse(xhr.responseText);
                    if (d.ok && d.notifications) {
                        var el = document.getElementById('notifCount');
                        var dd = document.getElementById('notifDropdown');
                        el.textContent = d.notifications.length;
                        el.style.display = d.notifications.length ? 'inline-flex' : 'none';
                        dd.innerHTML = d.notifications.length ? d.notifications.map(function(n) {
                            return '<div class="notif-item" data-id="' + n.id + '"><strong>' + (n.title || '') + '</strong><br><small>' + (n.message || '') + '</small></div>';
                        }).join('') : '<div class="notif-item">No new notifications</div>';
                    }
                } catch (e) {}
            }
        };
        xhr.send();
    }
    document.getElementById('notifBtn').onclick = function() {
        var dd = document.getElementById('notifDropdown');
        dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
    };
    document.getElementById('notifDropdown').addEventListener('click', function(e) {
        var item = e.target.closest('.notif-item[data-id]');
        if (item) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', base + 'api/notifications.php?read=' + item.getAttribute('data-id'));
            xhr.send();
            fetchNotifs();
        }
    });
    setInterval(fetchNotifs, 15000);
    fetchNotifs();

    var ctx = document.getElementById('purokChart');
    if (ctx) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', base + 'api/chart_purok.php');
        xhr.onload = function() {
            if (xhr.status !== 200) {
                ctx.parentNode.innerHTML = '<p style="color:#64748b;">Could not load chart data.</p>';
                return;
            }
            try {
                var d = JSON.parse(xhr.responseText);
                if (!d.ok) {
                    ctx.parentNode.innerHTML = '<p style="color:#64748b;">No data.</p>';
                    return;
                }
                var labels = d.labels || [];
                var data = d.data || [];
                if (labels.length === 0) { labels = ['No reports yet']; data = [0]; }
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Number of Reports',
                            data: data,
                            backgroundColor: 'rgba(15, 118, 110, 0.75)',
                            borderColor: 'rgb(15, 118, 110)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            title: { display: false }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: { stepSize: 1 },
                                grid: { color: 'rgba(0,0,0,0.06)' },
                                title: { display: true, text: 'Number of Reports' }
                            },
                            x: {
                                grid: { display: false },
                                ticks: { maxRotation: 45, minRotation: 0 }
                            }
                        }
                    }
                });
            } catch (e) {
                ctx.parentNode.innerHTML = '<p style="color:#64748b;">Chart error.</p>';
            }
        };
        xhr.onerror = function() {
            ctx.parentNode.innerHTML = '<p style="color:#64748b;">Could not load chart. Check api/chart_purok.php.</p>';
        };
        xhr.send();
    }
})();
</script>
</body>
</html>
