<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
$pending = $conn->query("SELECT COUNT(*) as t FROM incidents WHERE status='Pending'")->fetch_assoc()['t'] ?? 0;
$assigned = $conn->query("SELECT COUNT(*) as t FROM incidents WHERE status='Assigned'")->fetch_assoc()['t'] ?? 0;
$progress = $conn->query("SELECT COUNT(*) as t FROM incidents WHERE status='In Progress'")->fetch_assoc()['t'] ?? 0;
$resolved = $conn->query("SELECT COUNT(*) as t FROM incidents WHERE status='Resolved'")->fetch_assoc()['t'] ?? 0;
$rejected = $conn->query("SELECT COUNT(*) as t FROM incidents WHERE status='Rejected'")->fetch_assoc()['t'] ?? 0;
$byType = $conn->query("SELECT report_type, COUNT(*) as cnt FROM incidents GROUP BY report_type ORDER BY cnt DESC");
$typeLabels = [];
$typeVals = [];
if ($byType) while ($r = $byType->fetch_assoc()) {
    $typeLabels[] = addslashes($r['report_type']);
    $typeVals[] = (int)$r['cnt'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - Barangay System</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php">Incidents</a>
    <a href="duplicate_incidents.php">Duplicates</a>
    <a href="announcements.php">Announcements</a>
    <a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php" class="active">Analytics</a>
    <a href="budget_report.php">Budget</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Incident Analytics</h2></div>
    <div style="display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 32px;">
        <div class="card"><h3>Pending</h3><h1><?= $pending ?></h1></div>
        <div class="card"><h3>Assigned</h3><h1><?= $assigned ?></h1></div>
        <div class="card"><h3>In Progress</h3><h1><?= $progress ?></h1></div>
        <div class="card"><h3>Resolved</h3><h1><?= $resolved ?></h1></div>
        <div class="card"><h3>Rejected</h3><h1><?= $rejected ?></h1></div>
    </div>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; max-width: 900px;">
        <div class="card" style="padding: 24px;">
            <h3 style="margin: 0 0 20px;">Status Distribution</h3>
            <canvas id="statusChart" height="250"></canvas>
        </div>
        <div class="card" style="padding: 24px;">
            <h3 style="margin: 0 0 20px;">By Report Type</h3>
            <canvas id="typeChart" height="250"></canvas>
        </div>
    </div>
</div>
<script>
const statusData = [<?= $pending ?>, <?= $assigned ?>, <?= $progress ?>, <?= $resolved ?>, <?= $rejected ?>];
const typeLabels = [<?php echo implode(',', array_map(function($l){ return "'".$l."'"; }, $typeLabels)); ?>];
const typeData = [<?= implode(',', $typeVals ?: [0]) ?>];
new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: ['Pending', 'Assigned', 'In Progress', 'Resolved', 'Rejected'],
        datasets: [{ data: statusData, backgroundColor: ['#f59e0b', '#6366f1', '#3b82f6', '#10b981', '#ef4444'] }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});
new Chart(document.getElementById('typeChart'), {
    type: 'bar',
    data: {
        labels: typeLabels,
        datasets: [{ label: 'Count', data: typeData, backgroundColor: '#0f766e' }]
    },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } } }
});
</script>
</body>
</html>
