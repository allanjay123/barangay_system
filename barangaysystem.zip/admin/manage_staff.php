<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
$success = "";
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $role_id = (int)($_POST['role_id'] ?? 0);
    if ($user_id && $role_id) {
        $check = $conn->query("SELECT id FROM staff_accounts WHERE user_id=$user_id");
        if ($check && $check->num_rows > 0) {
            $error = "User is already a staff member.";
        } else {
            $conn->query("INSERT INTO staff_accounts (user_id, role_id) VALUES ($user_id, $role_id)");
            $conn->query("UPDATE users SET role='staff' WHERE id=$user_id");
            $success = "Staff added successfully.";
        }
    }
}
$staff = $conn->query("SELECT sa.id, u.full_name, u.email, sr.role_name FROM staff_accounts sa JOIN users u ON sa.user_id=u.id JOIN staff_roles sr ON sa.role_id=sr.id ORDER BY u.full_name");
$users = $conn->query("SELECT id, full_name FROM users WHERE role IN ('resident','user') ORDER BY full_name");
$roles = $conn->query("SELECT * FROM staff_roles ORDER BY role_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Management - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php">Incidents</a>
    <a href="duplicate_incidents.php">Duplicates</a>
    <a href="announcements.php">Announcements</a>
    <a href="manage_staff.php" class="active">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php">Analytics</a>
    <a href="budget_report.php">Budget</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Manage Staff</h2></div>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
    <?php if ($users && $users->num_rows > 0 && $roles && $roles->num_rows > 0): ?>
    <div class="form-card" style="margin-bottom: 32px; max-width: 500px;">
        <h3 style="margin: 0 0 20px;">Add Staff Member</h3>
        <form method="POST">
            <label>Select Resident</label>
            <select name="user_id" required>
                <option value="">-- Select --</option>
                <?php while ($u = $users->fetch_assoc()): ?>
                <option value="<?= (int)$u['id'] ?>"><?= htmlspecialchars($u['full_name']) ?></option>
                <?php endwhile; ?>
            </select>
            <label>Staff Role</label>
            <select name="role_id" required>
                <?php while ($r = $roles->fetch_assoc()): ?>
                <option value="<?= (int)$r['id'] ?>"><?= htmlspecialchars($r['role_name']) ?></option>
                <?php endwhile; ?>
            </select>
            <button type="submit" name="add" class="btn btn-primary">Add Staff</button>
        </form>
    </div>
    <?php endif; ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($staff && $staff->num_rows > 0): while ($row = $staff->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><?= htmlspecialchars($row['email'] ?? '-') ?></td>
                    <td><span class="badge badge-progress"><?= htmlspecialchars($row['role_name']) ?></span></td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="3" style="text-align:center; padding: 40px; color: #64748b;">No staff members yet. Add residents as staff above.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
