<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'staff'])) {
    header("Location: ../auth/login.php");
    exit;
}
require_once "../config/notify.php";
require_once "../config/audit.php";

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        $id = (int)($_POST['id'] ?? 0);
        $status = $conn->real_escape_string($_POST['status'] ?? '');
        if ($id && in_array($status, ['Pending', 'Assigned', 'In Progress', 'Resolved', 'Rejected'])) {
            if ($status === 'Resolved') {
                header("Location: resolve_incident.php?id=$id");
                exit;
            }
            $old = $conn->query("SELECT user_id, status, incident_code FROM incidents WHERE id=$id")->fetch_assoc();
            $conn->query("UPDATE incidents SET status='$status', updated_at=NOW() WHERE id=$id");
            if ($old && (int)$old['user_id'] > 0 && $old['status'] !== $status) {
                if ($status === 'In Progress') {
                    create_notification($conn, 'resident', 'status_update', 'On the way', "Your report is now being addressed.", (int)$old['user_id'], $id);
                } elseif ($status === 'Resolved') {
                    create_notification($conn, 'resident', 'status_update', 'Report resolved', "Your report has been resolved. You may give feedback.", (int)$old['user_id'], $id);
                }
            }
            audit_log($conn, 'incident_status_update', 'incident', $id, ($old['status'] ?? '') . ' -> ' . $status . ' (' . ($old['incident_code'] ?? '') . ')');
            $message = "Status updated.";
        }
    } elseif (isset($_POST['delete']) && $_SESSION['role'] === 'admin') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $code = $conn->query("SELECT incident_code FROM incidents WHERE id=$id")->fetch_assoc();
            $conn->query("DELETE FROM incident_photos WHERE incident_id=$id");
            @$conn->query("DELETE FROM incident_logs WHERE incident_id=$id");
            @$conn->query("DELETE FROM incident_after_photos WHERE incident_id=$id");
            $conn->query("DELETE FROM incidents WHERE id=$id");
            audit_log($conn, 'incident_deleted', 'incident', $id, 'Deleted: ' . ($code['incident_code'] ?? ''));
            $message = "Incident deleted.";
        }
    }
}

$data = $conn->query("SELECT i.*, u.full_name as reporter FROM incidents i LEFT JOIN users u ON i.user_id=u.id LEFT JOIN incident_merges m ON m.merged_incident_id = i.id WHERE m.id IS NULL ORDER BY i.created_at DESC");
$photo_counts = [];
$pc = $conn->query("SELECT incident_id, COUNT(*) as c FROM incident_photos GROUP BY incident_id");
if ($pc) while ($r = $pc->fetch_assoc()) $photo_counts[(int)$r['incident_id']] = (int)$r['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Incidents - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3><?= $_SESSION['role'] === 'admin' ? 'Admin' : 'Staff' ?> Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php" class="active">Incidents</a>
    <?php if ($_SESSION['role'] === 'admin'): ?><a href="duplicate_incidents.php">Duplicates</a><?php endif; ?>
    <a href="announcements.php">Announcements</a>
    <?php if ($_SESSION['role'] === 'admin'): ?><a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php">Analytics</a>
    <a href="budget_report.php">Budget</a>
    <a href="audit_logs.php">Audit Logs</a><?php endif; ?>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Manage Incidents</h2></div>
    <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <p style="color:#64748b; margin-top: -8px;">Street & Zone from reporter. <strong>Photos</strong> = pictures sent by user. View Map = pin location.</p>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Type</th>
                    <th>Reporter</th>
                    <th>Purok</th>
                    <th>Street</th>
                    <th>Zone</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Photos</th>
                    <th>Map</th>
                    <th>Slip</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($data && $data->num_rows > 0): while ($row = $data->fetch_assoc()): 
                    $statusClass = strtolower(str_replace(' ', '-', $row['status'] ?? 'pending'));
                    if ($statusClass === 'in-progress') $statusClass = 'progress';
                    $street = isset($row['street']) ? trim($row['street']) : '';
                    $zone   = isset($row['zone'])   ? trim($row['zone'])   : '';
                    $nphotos = isset($photo_counts[(int)$row['id']]) ? $photo_counts[(int)$row['id']] : 0;
                ?>
                <tr>
                    <td><strong><?= htmlspecialchars($row['incident_code']) ?></strong></td>
                    <td><?= htmlspecialchars($row['report_type']) ?></td>
                    <td><?= htmlspecialchars($row['reporter'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['purok'] ?? '') ?: '-' ?></td>
                    <td><?= htmlspecialchars($street) ?: '-' ?></td>
                    <td><?= htmlspecialchars($zone) ?: '-' ?></td>
                    <td><span class="badge badge-<?= $statusClass ?>"><?= htmlspecialchars($row['status'] ?? 'Pending') ?></span></td>
                    <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                    <td>
                        <?php if ($nphotos > 0): ?>
                        <a href="view_incident_photos.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-primary" target="_blank">📷 View (<?= $nphotos ?>)</a>
                        <?php else: ?>-
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!empty($row['lat']) && !empty($row['lng'])): ?>
                        <a href="view_incident_map.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-secondary" target="_blank">View Map</a>
                        <?php else: ?>-
                        <?php endif; ?>
                    </td>
                    <td><a href="../user/acknowledgement_slip.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-secondary" target="_blank">Slip</a></td>
                    <td>
                        <form method="POST" style="display:flex; gap:6px; align-items:center; flex-wrap:wrap;">
                            <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                            <select name="status" style="width:auto; margin:0; padding:6px 10px;">
                                <option <?= ($row['status'] ?? '') === 'Pending' ? 'selected' : '' ?>>Pending</option>
                                <option <?= ($row['status'] ?? '') === 'Assigned' ? 'selected' : '' ?>>Assigned</option>
                                <option <?= ($row['status'] ?? '') === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                                <option <?= ($row['status'] ?? '') === 'Resolved' ? 'selected' : '' ?>>Resolved</option>
                                <option <?= ($row['status'] ?? '') === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                            </select>
                            <small style="display:block; color:#64748b;">To mark Resolved: use &quot;Resolve (upload after photo)&quot; button.</small>
                            <button type="submit" name="update" class="btn btn-sm btn-primary">Update</button>
                            <?php if (($row['status'] ?? '') !== 'Resolved'): ?>
                            <a href="resolve_incident.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-primary" style="background:#059669;">Resolve (upload after photo)</a>
                            <?php endif; ?>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <button type="submit" name="delete" class="btn btn-sm btn-secondary" onclick="return confirm('Delete this incident?');" style="background:#fee2e2; color:#991b1b;">Delete</button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="12" style="text-align:center; padding: 40px; color: #64748b;">No incidents yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
