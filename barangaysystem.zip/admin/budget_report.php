<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
require_once "../config/audit.php";
$incCols = [];
$c = $conn->query("SHOW COLUMNS FROM incidents");
while ($r = $c->fetch_assoc()) $incCols[] = $r['Field'];
$has_estimated = in_array('estimated_cost', $incCols);
$has_actual = in_array('actual_cost', $incCols);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_cost'])) {
    $id = (int)($_POST['id'] ?? 0);
    $est = isset($_POST['estimated_cost']) && $_POST['estimated_cost'] !== '' ? (float)$_POST['estimated_cost'] : null;
    $act = isset($_POST['actual_cost']) && $_POST['actual_cost'] !== '' ? (float)$_POST['actual_cost'] : null;
    if ($id && $has_estimated) {
        $est_sql = $est !== null ? $est : "NULL";
        $act_sql = $has_actual && $act !== null ? $act : "NULL";
        if ($has_actual) $conn->query("UPDATE incidents SET estimated_cost=$est_sql, actual_cost=$act_sql WHERE id=$id");
        else $conn->query("UPDATE incidents SET estimated_cost=$est_sql WHERE id=$id");
        $code = $conn->query("SELECT incident_code FROM incidents WHERE id=$id")->fetch_assoc();
        audit_log($conn, 'incident_cost_updated', 'incident', $id, 'Est: ' . ($est !== null ? $est : '-') . ' Act: ' . ($act !== null ? $act : '-') . ' (' . ($code['incident_code'] ?? '') . ')');
    }
}

$month = isset($_GET['month']) ? $conn->real_escape_string($_GET['month']) : date('Y-m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
$list = $conn->query("SELECT i.id, i.incident_code, i.report_type, i.status, i.created_at, i.estimated_cost, i.actual_cost FROM incidents i LEFT JOIN incident_merges m ON m.merged_incident_id = i.id WHERE m.id IS NULL ORDER BY i.created_at DESC");
$monthly = $has_estimated ? $conn->query("SELECT SUM(COALESCE(i.estimated_cost,0)) as est, SUM(COALESCE(i.actual_cost,0)) as act FROM incidents i LEFT JOIN incident_merges m ON m.merged_incident_id = i.id WHERE m.id IS NULL AND DATE_FORMAT(i.created_at,'%Y-%m')='$month'")->fetch_assoc() : ['est'=>0,'act'=>0];
$yearly = $has_estimated ? $conn->query("SELECT SUM(COALESCE(i.estimated_cost,0)) as est, SUM(COALESCE(i.actual_cost,0)) as act FROM incidents i LEFT JOIN incident_merges m ON m.merged_incident_id = i.id WHERE m.id IS NULL AND YEAR(i.created_at)=$year")->fetch_assoc() : ['est'=>0,'act'=>0];

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=budget_report_' . date('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Code','Type','Status','Date','Estimated Cost','Actual Cost']);
    $list->data_seek(0);
    while ($row = $list->fetch_assoc()) {
        fputcsv($out, [$row['incident_code'], $row['report_type'], $row['status'], $row['created_at'], $row['estimated_cost'] ?? '', $row['actual_cost'] ?? '']);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Report - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php">Incidents</a>
    <a href="duplicate_incidents.php">Duplicates</a>
    <a href="announcements.php">Announcements</a>
    <a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php">Analytics</a>
    <a href="budget_report.php" class="active">Budget</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Budget Impact Estimation</h2></div>
    <p style="color:#64748b;">Residents cannot see cost details. For budget proposal, audit, council meeting.</p>
    <div class="card" style="display:block; margin-bottom:20px;">
        <h3>Monthly summary (<?= htmlspecialchars($month) ?>)</h3>
        <p>Estimated: ₱<?= number_format($monthly['est'] ?? 0, 2) ?> &nbsp; Actual: ₱<?= number_format($monthly['act'] ?? 0, 2) ?></p>
        <form method="get" style="display:inline-block;">
            <input type="month" name="month" value="<?= htmlspecialchars($month) ?>">
            <button type="submit" class="btn btn-sm btn-primary">Go</button>
        </form>
    </div>
    <div class="card" style="display:block; margin-bottom:20px;">
        <h3>Yearly summary (<?= $year ?>)</h3>
        <p>Estimated: ₱<?= number_format($yearly['est'] ?? 0, 2) ?> &nbsp; Actual: ₱<?= number_format($yearly['act'] ?? 0, 2) ?></p>
        <form method="get" style="display:inline-block;">
            <input type="hidden" name="year" value="<?= $year ?>">
            <input type="number" name="year" value="<?= $year ?>" min="2020" max="2030" style="width:100px;">
            <button type="submit" class="btn btn-sm btn-primary">Go</button>
        </form>
    </div>
    <p>
        <a href="budget_report.php?export=csv" class="btn btn-primary">Export Excel (CSV)</a>
        <button type="button" class="btn btn-secondary" onclick="window.print();">Print / PDF</button>
    </p>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Estimated cost</th>
                    <th>Actual cost</th>
                    <?php if ($has_estimated): ?><th>Set cost</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if ($list && $list->num_rows > 0): while ($row = $list->fetch_assoc()): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($row['incident_code']) ?></strong></td>
                    <td><?= htmlspecialchars($row['report_type']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                    <td>₱<?= number_format($row['estimated_cost'] ?? 0, 2) ?></td>
                    <td>₱<?= number_format($row['actual_cost'] ?? 0, 2) ?></td>
                    <?php if ($has_estimated): ?>
                    <td>
                        <form method="POST" style="display:flex;gap:6px;align-items:center;">
                            <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                            <input type="number" name="estimated_cost" step="0.01" min="0" placeholder="Est." value="<?= $row['estimated_cost'] !== null ? $row['estimated_cost'] : '' ?>" style="width:80px;">
                            <input type="number" name="actual_cost" step="0.01" min="0" placeholder="Actual" value="<?= $row['actual_cost'] !== null ? $row['actual_cost'] : '' ?>" style="width:80px;">
                            <button type="submit" name="save_cost" class="btn btn-sm btn-primary">Save</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="7" style="text-align:center;padding:40px;">No data.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
