<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
$list = $conn->query("SELECT i.id, i.incident_code, i.report_type, i.rating, i.feedback, i.updated_at, u.full_name as reporter FROM incidents i LEFT JOIN users u ON i.user_id=u.id WHERE (i.rating IS NOT NULL AND i.rating > 0) OR (i.feedback IS NOT NULL AND i.feedback != '') ORDER BY i.updated_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Monitoring - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php">Incidents</a>
    <a href="duplicate_incidents.php">Duplicates</a>
    <a href="announcements.php">Announcements</a>
    <a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php" class="active">Feedback</a>
    <a href="analytics.php">Analytics</a>
    <a href="budget_report.php">Budget</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Feedback Monitoring</h2></div>
    <p style="color: #64748b; margin-top: -8px;">View citizens' ratings and comments on resolved reports.</p>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Type</th>
                    <th>Reporter</th>
                    <th>Rating</th>
                    <th>Comment</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($list && $list->num_rows > 0): while ($row = $list->fetch_assoc()): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($row['incident_code']) ?></strong></td>
                    <td><?= htmlspecialchars($row['report_type']) ?></td>
                    <td><?= htmlspecialchars($row['reporter'] ?? '-') ?></td>
                    <td>
                        <?php
                        $r = (int)($row['rating'] ?? 0);
                        echo $r ? str_repeat('★', $r) . str_repeat('☆', 5 - $r) . " ($r/5)" : '-';
                        ?>
                    </td>
                    <td style="max-width: 320px;"><?= nl2br(htmlspecialchars($row['feedback'] ?? '-')) ?></td>
                    <td><?= $row['updated_at'] ? date('M d, Y H:i', strtotime($row['updated_at'])) : '-' ?></td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="6" style="text-align:center; padding: 40px; color: #64748b;">No feedback yet. Residents can rate and comment once their report is resolved.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
