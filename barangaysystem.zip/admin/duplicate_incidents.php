<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
require_once "../config/audit.php";

$message = "";
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['merge'])) {
        $primary_id = (int)($_POST['primary_id'] ?? 0);
        $merged_id = (int)($_POST['merged_id'] ?? 0);
        $reason = $conn->real_escape_string(trim($_POST['merge_reason'] ?? ''));
        if ($primary_id && $merged_id && $primary_id !== $merged_id) {
            $exists = $conn->query("SELECT id FROM incident_merges WHERE merged_incident_id=$merged_id");
            if ($exists && $exists->num_rows > 0) {
                $error = "One of these incidents was already merged.";
            } else {
                $user_id = (int)$_SESSION['user_id'];
                $conn->query("INSERT INTO incident_merges (primary_incident_id, merged_incident_id, merged_by, reason) VALUES ($primary_id, $merged_id, $user_id, '$reason')");
                audit_log($conn, 'incident_merged', 'incident', $primary_id, "Merged incident $merged_id into $primary_id. Reason: $reason");
                $message = "Incidents merged. The merged report is now hidden from the main list.";
            }
        } else {
            $error = "Invalid selection.";
        }
    } elseif (isset($_POST['keep_separate'])) {
        $incident_id = (int)($_POST['incident_id'] ?? 0);
        $related_id = (int)($_POST['related_incident_id'] ?? 0);
        $reason = $conn->real_escape_string(trim($_POST['keep_reason'] ?? ''));
        if ($incident_id && $related_id && $incident_id !== $related_id) {
            $user_id = (int)$_SESSION['user_id'];
            $conn->query("INSERT INTO incident_keep_separate (incident_id, related_incident_id, reason, decided_by) VALUES ($incident_id, $related_id, '$reason', $user_id)");
            audit_log($conn, 'incident_keep_separate', 'incident', $incident_id, "Decided to keep separate from $related_id. Reason: $reason");
            $message = "Marked as keep separate. This pair will no longer be suggested.";
        } else {
            $error = "Invalid selection.";
        }
    }
}

$merged_ids = [];
$m = $conn->query("SELECT merged_incident_id FROM incident_merges");
if ($m) while ($r = $m->fetch_assoc()) $merged_ids[(int)$r['merged_incident_id']] = true;

$keep_pairs = [];
$k = $conn->query("SELECT incident_id, related_incident_id FROM incident_keep_separate");
if ($k) while ($r = $k->fetch_assoc()) {
    $a = (int)$r['incident_id'];
    $b = (int)$r['related_incident_id'];
    $keep_pairs[$a . '_' . $b] = true;
    $keep_pairs[$b . '_' . $a] = true;
}

function is_merged($id, $merged_ids) {
    return isset($merged_ids[(int)$id]);
}
function is_keep_separate($a, $b, $keep_pairs) {
    return isset($keep_pairs[(int)$a . '_' . (int)$b]);
}

$pairs = [];
$seen_pair = [];

$same_issue = $conn->query("SELECT incident_id, related_incident_id FROM incident_same_issue");
if ($same_issue) while ($r = $same_issue->fetch_assoc()) {
    $a = (int)$r['incident_id'];
    $b = (int)$r['related_incident_id'];
    if (is_merged($a, $merged_ids) || is_merged($b, $merged_ids)) continue;
    if (is_keep_separate($a, $b, $keep_pairs)) continue;
    $key = $a < $b ? "$a,$b" : "$b,$a";
    if (!isset($seen_pair[$key])) {
        $seen_pair[$key] = true;
        $pairs[] = ['a' => $a, 'b' => $b, 'source' => 'User marked same issue'];
    }
}

$by_purok_type = [];
$all = $conn->query("SELECT id, incident_code, report_type, purok, created_at FROM incidents ORDER BY purok, report_type, id");
if ($all) while ($row = $all->fetch_assoc()) {
    $id = (int)$row['id'];
    if (is_merged($id, $merged_ids)) continue;
    $key = trim($row['purok']) . '|' . trim($row['report_type']);
    if ($key === '|') continue;
    if (!isset($by_purok_type[$key])) $by_purok_type[$key] = [];
    $by_purok_type[$key][] = $row;
}
foreach ($by_purok_type as $key => $list) {
    if (count($list) < 2) continue;
    for ($i = 0; $i < count($list); $i++) {
        for ($j = $i + 1; $j < count($list); $j++) {
            $a = (int)$list[$i]['id'];
            $b = (int)$list[$j]['id'];
            if (is_keep_separate($a, $b, $keep_pairs)) continue;
            $pkey = $a < $b ? "$a,$b" : "$b,$a";
            if (!isset($seen_pair[$pkey])) {
                $seen_pair[$pkey] = true;
                $pairs[] = ['a' => $a, 'b' => $b, 'source' => 'Same purok & report type'];
            }
        }
    }
}

$inc_info = [];
$all2 = $conn->query("SELECT id, incident_code, report_type, purok, created_at FROM incidents");
if ($all2) while ($row = $all2->fetch_assoc()) $inc_info[(int)$row['id']] = $row;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Duplicate Incidents - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php">Incidents</a>
    <a href="duplicate_incidents.php" class="active">Duplicates</a>
    <a href="announcements.php">Announcements</a>
    <a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php">Analytics</a>
    <a href="budget_report.php">Budget</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Possible Duplicate Incidents</h2></div>
    <p style="color:#64748b;">Merge two reports into one, or mark as keep separate (with reason). All actions are logged.</p>
    <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if (empty($pairs)): ?>
    <div class="alert alert-success">No duplicate suggestions at the moment.</div>
    <?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Incident A</th>
                    <th>Incident B</th>
                    <th>Source</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pairs as $p):
                    $info_a = $inc_info[$p['a']] ?? null;
                    $info_b = $inc_info[$p['b']] ?? null;
                    if (!$info_a || !$info_b) continue;
                ?>
                <tr>
                    <td>
                        <strong><?= htmlspecialchars($info_a['incident_code']) ?></strong><br>
                        <?= htmlspecialchars($info_a['report_type']) ?> · <?= htmlspecialchars($info_a['purok'] ?? '') ?><br>
                        <small><?= date('M d, Y', strtotime($info_a['created_at'])) ?></small>
                    </td>
                    <td>
                        <strong><?= htmlspecialchars($info_b['incident_code']) ?></strong><br>
                        <?= htmlspecialchars($info_b['report_type']) ?> · <?= htmlspecialchars($info_b['purok'] ?? '') ?><br>
                        <small><?= date('M d, Y', strtotime($info_b['created_at'])) ?></small>
                    </td>
                    <td><small><?= htmlspecialchars($p['source']) ?></small></td>
                    <td style="vertical-align:middle;">
                        <form method="POST" style="margin-bottom:8px;" class="merge-form" data-a="<?= $p['a'] ?>" data-b="<?= $p['b'] ?>">
                            <label style="font-size:0.85rem;">Merge into: </label>
                            <select name="primary_id" class="merge-primary" style="width:auto;">
                                <option value="<?= $p['a'] ?>"><?= htmlspecialchars($info_a['incident_code']) ?></option>
                                <option value="<?= $p['b'] ?>"><?= htmlspecialchars($info_b['incident_code']) ?></option>
                            </select>
                            <input type="hidden" name="merged_id" class="merge-merged" value="<?= $p['b'] ?>">
                            <input type="text" name="merge_reason" placeholder="Reason (optional)" style="width:180px; margin:4px 0;">
                            <button type="submit" name="merge" class="btn btn-sm btn-primary">Merge</button>
                        </form>
                        <form method="POST">
                            <input type="hidden" name="incident_id" value="<?= $p['a'] ?>">
                            <input type="hidden" name="related_incident_id" value="<?= $p['b'] ?>">
                            <input type="text" name="keep_reason" placeholder="Reason to keep separate" style="width:180px; margin:4px 0;" required>
                            <button type="submit" name="keep_separate" class="btn btn-sm btn-secondary">Keep separate</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<script>
document.querySelectorAll('form.merge-form').forEach(function(f) {
    var a = parseInt(f.getAttribute('data-a'), 10);
    var b = parseInt(f.getAttribute('data-b'), 10);
    var sel = f.querySelector('select.merge-primary');
    var hid = f.querySelector('input.merge-merged');
    if (!sel || !hid) return;
    function update() {
        var primary = parseInt(sel.value, 10);
        hid.value = (primary === a) ? b : a;
    }
    sel.addEventListener('change', update);
    update();
});
</script>
</body>
</html>
