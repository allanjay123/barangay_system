<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
require_once "../config/audit.php";
$success = "";
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $title = $conn->real_escape_string(trim($_POST['title'] ?? ''));
        $content = $conn->real_escape_string(trim($_POST['content'] ?? ''));
        $urgency = $conn->real_escape_string($_POST['urgency'] ?? 'normal');
        $expiry = !empty($_POST['expiry_date']) ? "'" . $conn->real_escape_string($_POST['expiry_date']) . "'" : "NULL";
        $is_pinned = isset($_POST['is_pinned']) ? 1 : 0;
        if (empty($title) || empty($content)) {
            $error = "Title and content are required.";
        } else {
            $conn->query("INSERT INTO announcements (title, content, urgency, expiry_date, is_pinned, created_at) VALUES ('$title', '$content', '$urgency', $expiry, $is_pinned, NOW())");
            audit_log($conn, 'announcement_added', 'announcement', $conn->insert_id, $title);
            $success = "Announcement added.";
        }
    } elseif (isset($_POST['edit'])) {
        $id = (int)($_POST['id'] ?? 0);
        $title = $conn->real_escape_string(trim($_POST['title'] ?? ''));
        $content = $conn->real_escape_string(trim($_POST['content'] ?? ''));
        $urgency = $conn->real_escape_string($_POST['urgency'] ?? 'normal');
        $expiry = !empty($_POST['expiry_date']) ? "'" . $conn->real_escape_string($_POST['expiry_date']) . "'" : "NULL";
        $is_pinned = isset($_POST['is_pinned']) ? 1 : 0;
        if ($id && !empty($title) && !empty($content)) {
            $conn->query("UPDATE announcements SET title='$title', content='$content', urgency='$urgency', expiry_date=$expiry, is_pinned=$is_pinned WHERE id=$id");
            audit_log($conn, 'announcement_updated', 'announcement', $id, $title);
            $success = "Announcement updated.";
        }
    } elseif (isset($_POST['delete'])) {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $row = $conn->query("SELECT title FROM announcements WHERE id=$id")->fetch_assoc();
            $conn->query("DELETE FROM announcements WHERE id=$id");
            audit_log($conn, 'announcement_deleted', 'announcement', $id, $row['title'] ?? '');
            $success = "Announcement deleted.";
        }
    }
}
$data = $conn->query("SELECT * FROM announcements ORDER BY is_pinned DESC, created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - Barangay System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_incidents.php">Incidents</a>
    <a href="duplicate_incidents.php">Duplicates</a>
    <a href="announcements.php" class="active">Announcements</a>
    <a href="manage_staff.php">Staff</a>
    <a href="feedback_monitoring.php">Feedback</a>
    <a href="analytics.php">Analytics</a>
    <a href="budget_report.php">Budget</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="../auth/logout.php">Logout</a>
</div>
<div class="main">
    <div class="page-header"><h2>Manage Announcements (CRUD)</h2></div>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
    <div class="form-card" style="margin-bottom: 32px;">
        <h3 style="margin: 0 0 20px;">Create – Add Announcement</h3>
        <form method="POST">
            <input type="text" name="title" placeholder="Title" required>
            <textarea name="content" rows="4" placeholder="Content" required></textarea>
            <label>Urgency</label>
            <select name="urgency">
                <option value="normal">Normal</option>
                <option value="high">High</option>
            </select>
            <label>Expiry Date (optional)</label>
            <input type="date" name="expiry_date">
            <label style="display: flex; align-items: center; gap: 8px;"><input type="checkbox" name="is_pinned" value="1"> Pin to top</label>
            <button type="submit" name="add" class="btn btn-primary">Add Announcement</button>
        </form>
    </div>
    <h3 style="margin-bottom: 16px;">Read / Update / Delete – All Announcements</h3>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Urgency</th>
                    <th>Pinned</th>
                    <th>Expiry</th>
                    <th>Created</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($data && $data->num_rows > 0): while ($row = $data->fetch_assoc()): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($row['title']) ?></strong><br><small style="color:#64748b;"><?= htmlspecialchars(substr($row['content'], 0, 80)) ?>...</small></td>
                    <td><span class="badge badge-<?= $row['urgency'] === 'high' ? 'rejected' : 'pending' ?>"><?= htmlspecialchars($row['urgency']) ?></span></td>
                    <td><?= !empty($row['is_pinned']) ? 'Yes' : 'No' ?></td>
                    <td><?= !empty($row['expiry_date']) ? date('M d, Y', strtotime($row['expiry_date'])) : '-' ?></td>
                    <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-secondary" onclick="editAnn(<?= (int)$row['id'] ?>, <?= json_encode($row['title']) ?>, <?= json_encode($row['content']) ?>, <?= json_encode($row['urgency'] ?? 'normal') ?>, <?= json_encode($row['expiry_date'] ?? '') ?>, <?= !empty($row['is_pinned']) ? 1 : 0 ?>)">Edit</button>
                    </td>
                    <td>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this announcement?');">
                            <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                            <button type="submit" name="delete" class="btn btn-sm btn-secondary" style="background:#fee2e2; color:#991b1b;">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="7" style="text-align:center; padding: 40px; color: #64748b;">No announcements yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div id="editModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:9999; align-items:center; justify-content:center;">
    <div class="form-card" style="max-width:500px; margin:20px;">
        <h3>Update Announcement</h3>
        <form method="POST" id="editForm">
            <input type="hidden" name="id" id="editId">
            <input type="hidden" name="edit" value="1">
            <input type="text" name="title" id="editTitle" placeholder="Title" required>
            <textarea name="content" id="editContent" rows="4" placeholder="Content" required></textarea>
            <label>Urgency</label>
            <select name="urgency" id="editUrgency">
                <option value="normal">Normal</option>
                <option value="high">High</option>
            </select>
            <label>Expiry Date</label>
            <input type="date" name="expiry_date" id="editExpiry">
            <label style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_pinned" id="editPinned" value="1"> Pin to top</label>
            <button type="submit" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-secondary" onclick="document.getElementById('editModal').style.display='none';">Cancel</button>
        </form>
    </div>
</div>
<script>
function editAnn(id, title, content, urgency, expiry, pinned) {
    document.getElementById('editId').value = id;
    document.getElementById('editTitle').value = title;
    document.getElementById('editContent').value = content;
    document.getElementById('editUrgency').value = urgency || 'normal';
    document.getElementById('editExpiry').value = expiry || '';
    document.getElementById('editPinned').checked = !!pinned;
    document.getElementById('editModal').style.display = 'flex';
}
document.getElementById('editModal').style.display = 'none';
</script>
</body>
</html>
