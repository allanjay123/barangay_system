<?php
require_once "../config/init.php";
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'staff'])) {
    header("Location: ../auth/login.php");
    exit;
}
$id = (int)($_GET['id'] ?? 0);
$inc = $conn->query("SELECT incident_code, report_type, lat, lng, purok, street, zone, location_text FROM incidents WHERE id=$id");
if (!$inc || $inc->num_rows === 0 || !$row = $inc->fetch_assoc()) {
    die("Incident not found.");
}
$lat = (float)($row['lat'] ?? 0);
$lng = (float)($row['lng'] ?? 0);
if ($lat === 0.0 && $lng === 0.0) { $lat = 14.5995; $lng = 120.9842; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Map - <?= htmlspecialchars($row['incident_code']) ?></title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        body { margin: 0; font-family: system-ui; }
        #map { height: 100vh; }
        .info { position: absolute; top: 10px; left: 50px; z-index: 1000; background: #fff; padding: 12px 16px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.15); max-width: 320px; }
    </style>
</head>
<body>
<div class="info">
    <strong><?= htmlspecialchars($row['incident_code']) ?></strong> — <?= htmlspecialchars($row['report_type']) ?><br>
    <?php if (!empty($row['purok'])): ?>Purok: <?= htmlspecialchars($row['purok']) ?><br><?php endif; ?>
    <?php if (!empty($row['street'])): ?>Street: <?= htmlspecialchars($row['street']) ?><br><?php endif; ?>
    <?php if (!empty($row['zone'])): ?>Zone: <?= htmlspecialchars($row['zone']) ?><br><?php endif; ?>
    <?php if (!empty($row['location_text'])): ?><?= htmlspecialchars($row['location_text']) ?><?php endif; ?>
</div>
<div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
var map = L.map('map').setView([<?= $lat ?>, <?= $lng ?>], 17);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap' }).addTo(map);
L.marker([<?= $lat ?>, <?= $lng ?>]).addTo(map).bindPopup("<?= addslashes($row['incident_code'] . ' - ' . $row['report_type']) ?>");
</script>
</body>
</html>
