<?php
/**
 * Run once to add new columns and notifications table.
 * Visit: http://localhost/barangay_system/install_migration.php
 */
require_once "config/db.php";
$done = [];
$errors = [];

$columns = ['street' => "VARCHAR(255) NULL", 'zone' => "VARCHAR(100) NULL", 'lat' => "DECIMAL(10,8) NULL", 'lng' => "DECIMAL(11,8) NULL"];
$r = $conn->query("SHOW COLUMNS FROM incidents");
$existing = [];
while ($row = $r->fetch_assoc()) $existing[] = $row['Field'];

foreach ($columns as $col => $def) {
    if (!in_array($col, $existing)) {
        if ($conn->query("ALTER TABLE incidents ADD COLUMN $col $def")) $done[] = "Added incidents.$col";
        else $errors[] = "Failed: $col";
    }
}

if ($conn->query("CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  for_role VARCHAR(20) NOT NULL,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT,
  related_id INT NULL,
  read_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_role (user_id, for_role),
  INDEX idx_read (read_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")) $done[] = "Notifications table OK";
else $errors[] = "Notifications table failed";

header('Content-Type: text/html; charset=utf-8');
echo "<h2>Migration</h2><p><strong>Done:</strong> " . implode(", ", $done) . "</p>";
if ($errors) echo "<p style='color:red'>" . implode(", ", $errors) . "</p>";
echo "<p><a href='auth/login.php'>Go to Login</a></p>";
echo "<p><small>You can delete this file after running once.</small></p>";
